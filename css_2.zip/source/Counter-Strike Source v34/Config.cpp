#include "Config.h"

float GetPrivateProfileFloat( LPCSTR lpAppName, LPCSTR lpKeyName, FLOAT flDefault, LPCSTR lpFileName )
{
	char szData[32];

	GetPrivateProfileStringA( lpAppName, lpKeyName, std::to_string( flDefault ).c_str( ), szData, 32, lpFileName );

	return ( float )atof( szData );
}

void WritePrivateProfileFloat( LPCSTR lpAppName, LPCSTR lpKeyName, FLOAT flValue, LPCSTR lpFileName )
{
	WritePrivateProfileStringA( lpAppName, lpKeyName, std::to_string( ( int )flValue ).c_str( ), lpFileName );
}
void CConfig::SetModule(HMODULE hModule)
{
	m_hModule = hModule;
}
void CConfig::Load(void)
{
	//
	// Get our module path
	//
	char szPath[MAX_PATH];

	GetModuleFileNameA(m_hModule, szPath, MAX_PATH);

	std::string path(szPath);

	//
	// Create config path
	//
	path = path.substr(0, path.find_last_of("\\") + 1);
	path.append("autoexec.cfg");

	//
	// Read vars
	//
	m_AimbotActive = GetPrivateProfileFloat("main", "aimbot.active", 0, path.c_str());
	m_AimbotAutoShoot = GetPrivateProfileFloat("main", "aimbot.autoshoot", 0, path.c_str());
	m_AimbotType = GetPrivateProfileFloat("main", "aimbot.type", 0, path.c_str());
	m_AimbotHitbox = GetPrivateProfileFloat("main", "aimbot.spot", 0, path.c_str());
	m_AimbotFOV = GetPrivateProfileFloat("main", "aimbot.fov", 0, path.c_str());
	m_AimbotKeys = GetPrivateProfileFloat("main", "aimbot.key", 0, path.c_str());
	m_AimbotSmooth = GetPrivateProfileFloat("main", "aimbot.smooth", 0, path.c_str());
	m_AimbotRCS = GetPrivateProfileFloat("main", "aimbot.rcs", 0, path.c_str());
	m_AimbotRCSDelay = GetPrivateProfileFloat("main", "aimbot.rcs.delay", 0, path.c_str());
	m_AimbotSilent = GetPrivateProfileFloat("main", "aimbot.silent", 0, path.c_str());
	m_AimbotPSilent = GetPrivateProfileFloat("main", "aimbot.psilent", 0, path.c_str());
	m_AimbotAutoWall = GetPrivateProfileFloat("main", "aimbot.autowall", 0, path.c_str());
	m_AimbotRcsX = GetPrivateProfileFloat("main", "aimbot.rcsx", 0, path.c_str());
	m_AimbotRcsY = GetPrivateProfileFloat("main", "aimbot.rcsy", 0, path.c_str());
	m_AimbotSmoothX = GetPrivateProfileFloat("main", "aimbot.linearx", 0, path.c_str());
	m_AimbotSmoothY = GetPrivateProfileFloat("main", "aimbot.lineary", 0, path.c_str());
	m_AimbotStepX = GetPrivateProfileFloat("main", "aimbot.stepx", 0, path.c_str());
	m_AimbotStepY = GetPrivateProfileFloat("main", "aimbot.stepy", 0, path.c_str());


	m_TriggerbotActive = GetPrivateProfileFloat("main", "triggerbot.active", 0, path.c_str());
	m_TriggerbotPerfect = GetPrivateProfileFloat("main", "triggerbot.perfect", 0, path.c_str());
	m_TriggerbotKey = GetPrivateProfileFloat("main", "triggerbot.key", 0, path.c_str());
	m_TriggerbotHitbox = GetPrivateProfileFloat("main", "triggerbot.hitbox", 0, path.c_str());

	m_EspActive = GetPrivateProfileFloat("main", "esp.active", 0, path.c_str());
	m_EspBox = GetPrivateProfileFloat("main", "esp.box", 0, path.c_str());
	m_EspHealth = GetPrivateProfileFloat("main", "esp.health", 0, path.c_str());
	m_EspArmor = GetPrivateProfileFloat("main", "esp.armor", 0, path.c_str());
	m_EspBone = GetPrivateProfileFloat("main", "esp.bone", 0, path.c_str());
	m_EspHitbox = GetPrivateProfileFloat("main", "esp.hitbox", 0, path.c_str());
	m_EspWeapon = GetPrivateProfileFloat("main", "esp.weapon", 0, path.c_str());
	m_EspVisible = GetPrivateProfileFloat("main", "esp.visible", 0, path.c_str());
	m_EspName = GetPrivateProfileFloat("main", "esp.name", 0, path.c_str());
	m_EspDefuse = GetPrivateProfileFloat("main", "esp.defuse", 0, path.c_str());

	m_RemSpread = GetPrivateProfileFloat("main", "removals.spread", 0, path.c_str());
	m_RemRecoil = GetPrivateProfileFloat("main", "removals.recoil", 0, path.c_str());
	m_RemVisualRecoil = GetPrivateProfileFloat("main", "removals.visual.recoil", 0, path.c_str());
	m_RemFlash = GetPrivateProfileFloat("main", "removals.flash", 0, path.c_str());
	m_RemBackflip = GetPrivateProfileFloat("main", "removals.backflip", 0, path.c_str());

	m_MiscBunnyHop = GetPrivateProfileFloat("main", "misc.bunnyhop", 0, path.c_str());
	m_MiscCrosshair = GetPrivateProfileFloat("main", "misc.crosshair", 0, path.c_str());
	m_MiscShowRecoilCrosshair = GetPrivateProfileFloat("main", "misc.recoilcrosshair", 0, path.c_str());
	m_aapitch = GetPrivateProfileFloat("main", "misc.pitch", 0, path.c_str());
	m_aayaw = GetPrivateProfileFloat("main", "misc.yaw", 0, path.c_str());




}

void CConfig::Save(void)
{
	//
	// Get our module path
	//
	char szPath[MAX_PATH];

	GetModuleFileNameA(m_hModule, szPath, MAX_PATH);

	std::string path(szPath);

	//
	// Create config path
	//
	path = path.substr(0, path.find_last_of("\\") + 1);
	path.append("autoexec.cfg");

	//
	// Read vars
	//
	m_AimbotActive = GetPrivateProfileFloat("main", "aimbot.active", 0, path.c_str());
	m_AimbotAutoShoot = GetPrivateProfileFloat("main", "aimbot.autoshoot", 0, path.c_str());
	m_AimbotType = GetPrivateProfileFloat("main", "aimbot.type", 0, path.c_str());
	m_AimbotHitbox = GetPrivateProfileFloat("main", "aimbot.spot", 0, path.c_str());
	m_AimbotFOV = GetPrivateProfileFloat("main", "aimbot.fov", 0, path.c_str());
	m_AimbotKeys = GetPrivateProfileFloat("main", "aimbot.key", 0, path.c_str());
	m_AimbotSmooth = GetPrivateProfileFloat("main", "aimbot.smooth", 0, path.c_str());
	m_AimbotRCS = GetPrivateProfileFloat("main", "aimbot.rcs", 0, path.c_str());
	m_AimbotRCSDelay = GetPrivateProfileFloat("main", "aimbot.rcs.delay", 0, path.c_str());
	m_AimbotSilent = GetPrivateProfileFloat("main", "aimbot.silent", 0, path.c_str());
	m_AimbotPSilent = GetPrivateProfileFloat("main", "aimbot.psilent", 0, path.c_str());
	m_AimbotAutoWall = GetPrivateProfileFloat("main", "aimbot.autowall", 0, path.c_str());
	m_AimbotRcsX = GetPrivateProfileFloat("main", "aimbot.rcsx", 0, path.c_str());
	m_AimbotRcsY = GetPrivateProfileFloat("main", "aimbot.rcsy", 0, path.c_str());
	m_AimbotSmoothX = GetPrivateProfileFloat("main", "aimbot.linearx", 0, path.c_str());
	m_AimbotSmoothY = GetPrivateProfileFloat("main", "aimbot.lineary", 0, path.c_str());
	m_AimbotStepX = GetPrivateProfileFloat("main", "aimbot.stepx", 0, path.c_str());
	m_AimbotStepY = GetPrivateProfileFloat("main", "aimbot.stepy", 0, path.c_str());


	m_TriggerbotActive = GetPrivateProfileFloat("main", "triggerbot.active", 0, path.c_str());
	m_TriggerbotPerfect = GetPrivateProfileFloat("main", "triggerbot.perfect", 0, path.c_str());
	m_TriggerbotKey = GetPrivateProfileFloat("main", "triggerbot.key", 0, path.c_str());
	m_TriggerbotHitbox = GetPrivateProfileFloat("main", "triggerbot.hitbox", 0, path.c_str());

	m_EspActive = GetPrivateProfileFloat("main", "esp.active", 0, path.c_str());
	m_EspBox = GetPrivateProfileFloat("main", "esp.box", 0, path.c_str());
	m_EspHealth = GetPrivateProfileFloat("main", "esp.health", 0, path.c_str());
	m_EspArmor = GetPrivateProfileFloat("main", "esp.armor", 0, path.c_str());
	m_EspBone = GetPrivateProfileFloat("main", "esp.bone", 0, path.c_str());
	m_EspHitbox = GetPrivateProfileFloat("main", "esp.hitbox", 0, path.c_str());
	m_EspWeapon = GetPrivateProfileFloat("main", "esp.weapon", 0, path.c_str());
	m_EspVisible = GetPrivateProfileFloat("main", "esp.visible", 0, path.c_str());
	m_EspName = GetPrivateProfileFloat("main", "esp.name", 0, path.c_str());
	m_EspDefuse = GetPrivateProfileFloat("main", "esp.defuse", 0, path.c_str());

	m_RemSpread = GetPrivateProfileFloat("main", "removals.spread", 0, path.c_str());
	m_RemRecoil = GetPrivateProfileFloat("main", "removals.recoil", 0, path.c_str());
	m_RemVisualRecoil = GetPrivateProfileFloat("main", "removals.visual.recoil", 0, path.c_str());
	m_RemFlash = GetPrivateProfileFloat("main", "removals.flash", 0, path.c_str());
	m_RemBackflip = GetPrivateProfileFloat("main", "removals.backflip", 0, path.c_str());

	m_MiscBunnyHop = GetPrivateProfileFloat("main", "misc.bunnyhop", 0, path.c_str());
	m_MiscCrosshair = GetPrivateProfileFloat("main", "misc.crosshair", 0, path.c_str());
	m_MiscShowRecoilCrosshair = GetPrivateProfileFloat("main", "misc.recoilcrosshair", 0, path.c_str());
	m_aapitch = GetPrivateProfileFloat("main", "misc.pitch", 0, path.c_str());
	m_aayaw = GetPrivateProfileFloat("main", "misc.yaw", 0, path.c_str());
}
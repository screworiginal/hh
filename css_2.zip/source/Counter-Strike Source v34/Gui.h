#ifndef __CMENU_H__
#define __CMENU_H__

#include "SDK.h"

enum eKeyFlags
{
	KEY_FLAG_NONE = 0,
	KEY_FLAG_MOUSE1,
	KEY_FLAG_MOUSE2,
	KEY_FLAG_MOUSE3 = 4,
	KEY_FLAG_MOUSE4,
	KEY_FLAG_MOUSE5,
};

class cMouse
{
public:
	bool IsInBox(int x, int y, int w, int h);
	bool KeyActive(int val);
	void ClickHandler();
	bool LeftClick(int x, int y, int w, int h);

public:
	bool bMouse1pressed,
		bMouse2pressed,
		bMouse1released,
		bMouse2released;
};

class CMenu
{
public:
	void ButtonKey(int x, int y, const char* szString, bool &toggle);
	void CloseAllComboBoxes();
	void DrawWindow(int x, int y, int w, int h, char* cName);
	void DrawGroupBox(int x, int y, int w, int h, char* Name);
	void DrawComboBox(int x, int y, char* Name, int &Selection, int num, int max, char** structs, char* Description);
	void DrawCheckBox(int x, int y, const char* szString, bool &toggle, char* Description);
	void DrawTabs(const char* Name, int tab, int x, int y);
	void DrawCloseButton(int x, int y);
	void DrawRadar(int x, int y);
	void Slider(int x, int y, bool bInt, float &iInput, float iMin, float iMax, char* Name, char* Description);
	void DrawPlayerList();
	void DrawMainFrame(int x, int y);
	void DrawMonitor(int x, int y);
	void DrawMenu();
	void RenderGroupBox(int x, int y, int w, int h, std::string strText);

	void RenderTab(int x, int y, float w, float h, std::string strText, int iIndex, int& iStatus);
	void RenderAimbotTab(int x, int y, int w, int h);
	void RenderTriggerbotTab(int x, int y, int w, int h);
	void RenderVisualsTab(int x, int y, int w, int);
	void RenderRender2Tab(int x, int y, int w, int);
	void RenderMiscTab(int x, int y, int w, int h);
	void RenderConfigTab(int x, int y, int w, int h);
	void DragRagebot(int w, int h);
	void DragLegitbot(int w, int h);
	void DragVisuals(int w, int h);
	void DragRender2(int w, int h);
	void DragMisc(int w, int h);
	void DragConfig(int w, int h);
	void RenderSlider(int x, int y, int w, int h, std::string strText, std::string strCVar, int isfloat);
	void Draw(int x, int y, int w, int h, const char *Text);
	void RenderButton(int x, int y, std::string strText, int iIndex, int& iClicked, bool untrusted);
	void RenderRemovalsTab(int x, int y, int w, int);
	void DragRemovalsbot(int w, int h);
private:
	int				m_iCurrentButtonTap;
	int				m_bMenuCombo;
	int			    WhichKeyIsPressed();
};

typedef struct
{
	int m_iWidth;
	int m_iHeight;
} ScreenSize_t;

extern ScreenSize_t sScreenSize;
extern ScreenSize_t sScreenSize2;

extern CMenu* g_pGameGui;

#endif
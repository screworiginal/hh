#include "Player.h"
#include "Main.h"
#include "Manager.h"

C_CSPlayer* C_CSPlayer::GetLocalPlayer( void )
{
	auto iLocal = Main::m_pEngine->GetLocalPlayer( );

	if( !iLocal )
		return nullptr;

	auto pLocal = Main::m_pEntList->GetClientEntity( iLocal );

	if( !pLocal )
		return nullptr;

	if( !pLocal->IsPlayer( ) )
		return nullptr;

	return ( C_CSPlayer* )pLocal;
}

int C_CSPlayer::GetHitboxSet( void )
{
	static auto var = Main::m_pManager->Get( "DT_BaseAnimating", "m_nHitboxSet" );

	return *( int* )( this + var );
}

C_WeaponCSBase*	C_CSPlayer::GetActiveWeapon( void )
{
	static auto var = Main::m_pManager->Get( "DT_BaseCombatCharacter", "m_hActiveWeapon" );

	auto hActiveWeapon = *( CBaseHandle* )( this + var );

	return ( C_WeaponCSBase* )Main::m_pEntList->GetClientEntityFromHandle( hActiveWeapon );
}

float C_CSPlayer::GetNextAttack( void )
{
	static auto var = Main::m_pManager->Get( "DT_BaseCombatCharacter", "m_flNextAttack" );

	return *( float* )( this + var );
}

int C_CSPlayer::GetFOV( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_iFOV" );

	return *( int* )( this + var );
}

int C_CSPlayer::GetFlags( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_fFlags" );

	return *( int* )( this + var );
}

Vector3 C_CSPlayer::GetPunchAngle( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_vecPunchAngle" );

	return *( Vector3* )( this + var );
}

Vector3 C_CSPlayer::GetViewOffset( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_vecViewOffset[0]" );

	return *( Vector3* )( this + var );
}

Vector3 C_CSPlayer::GetVelocity( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_vecVelocity[0]" );

	return *( Vector3* )( this + var );
}

int C_CSPlayer::GetTickBase( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_nTickBase" );

	return *( int* )( this + var );
}

int C_CSPlayer::GetHealth( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_iHealth" );

	return *( int* )( this + var );
}

bool C_CSPlayer::IsDead( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_lifeState" );

	return *( bool* )( this + var );
}

Matrix3x4 C_CSPlayer::GetCoordinateFrame( void )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_fFlags" ) - sizeof( Vector3 ) - sizeof( Vector3 ) - sizeof( Matrix3x4 );

	return *( Matrix3x4* )( this + var );
}

int C_CSPlayer::GetArmor( void )
{
	static auto var = Main::m_pManager->Get( "DT_CSPlayer", "m_ArmorValue" );

	return *( int* )( this + var );
}

bool C_CSPlayer::HasHelmet( void )
{
	static auto var = Main::m_pManager->Get( "DT_CSPlayer", "m_bHasHelmet" );

	return *( bool* )( this + var );
}

int C_CSPlayer::GetShotsFired( void )
{
	static auto var = Main::m_pManager->Get( "DT_CSPlayer", "m_iShotsFired" );

	return *( int* )( this + var );
}

Vector3 C_CSPlayer::GetEyePosition( void )
{
	return ( GetAbsOrigin( ) + GetViewOffset( ) );
}

bool C_CSPlayer::GetBonePosition( int iBone, Vector3& vOut )
{
	Matrix3x4 vMatrix[MAXSTUDIOBONES];

	if( !SetupBones( vMatrix, MAXSTUDIOBONES, BONE_USED_BY_HITBOX, Main::m_pServerData->curtime ) )
		return false;

	vOut.x = vMatrix[iBone][0][3];
	vOut.y = vMatrix[iBone][1][3];
	vOut.z = vMatrix[iBone][2][3];

	return !vOut.IsZero( );
}

bool C_CSPlayer::GetHitboxPosition( int iHitbox, Vector3& vOut )
{
	Matrix3x4 vMatrix[MAXSTUDIOBONES];

	if( !SetupBones( vMatrix, MAXSTUDIOBONES, BONE_USED_BY_HITBOX, Main::m_pServerData->curtime ) )
		return false;

	const model_t* pModel = GetModel( );

	if( !pModel )
		return false;

	studiohdr_t* pStudioHdr = Main::m_pModelData->GetStudioModel( pModel );

	if( !pStudioHdr )
		return false;

	mstudiohitboxset_t* pSet = pStudioHdr->GetHitboxSet( GetHitboxSet( ) );

	if( !pSet )
		return false;

	mstudiobbox_t* pBox = pSet->GetHitbox( iHitbox );

	if( !pBox )
		return false;

	Vector3 vMin, vMax;

	VectorTransform( pBox->bbmin, vMatrix[pBox->bone], vMin );
	VectorTransform( pBox->bbmax, vMatrix[pBox->bone], vMax );

	vOut = ( vMin + vMax ) * 0.5f;

	return !vOut.IsZero( );
}

void C_CSPlayer::SetPunchAngle( const Vector3& vecPunchAngle )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_vecPunchAngle" );

	*( Vector3* )( this + var ) = vecPunchAngle;
}

void C_CSPlayer::SetTickBase( int nTickBase )
{
	static auto var = Main::m_pManager->Get( "DT_BasePlayer", "m_nTickBase" );

	*( int* )( this + var ) = nTickBase;
}


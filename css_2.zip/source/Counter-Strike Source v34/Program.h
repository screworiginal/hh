#ifndef PROGRAM_H
#define PROGRAM_H

#pragma once

#include <windows.h>

#include <iostream>
#include <string>
#include <vector>
#include <future>
#include <fstream>

#include <tlhelp32.h>

#ifndef SAFE_RESET
	#define SAFE_RESET( x ) if( x ) { x.reset( ); x = nullptr; }
#endif // SAFE_RESET

#ifndef SAFE_DELETE
	#define SAFE_DELETE( x ) if( x ) { delete x; x = nullptr; }
#endif // SAFE_DELETE

#endif // PROGRAM_H
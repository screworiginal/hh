#ifndef AIMBOT_H
#define AIMBOT_H

#pragma once

#include "SDK.h"

class CAimbot
{
public:
					CAimbot( void );

	void			Execute( CUserCmd* pCmd );
	bool			CanHit( int random_seed, Vector3 viewangles );

private:
	void			DropTarget( void );
	void			GetBestTarget( void );

	bool			CanPenetrate( const Vector3& vStart, const Vector3& vEnd, int& iHitbox, int& iHitgroup, C_CSPlayer** ppPlayerHit, int iMinDamage );
	bool			Valid( int index );

	void			MakeVector( const Vector3& vIn, Vector3& vOut );
	float			GetFOV( const Vector3& viewangles, const Vector3& vStart, const Vector3& vEnd );

private:
	CUserCmd*		m_pCmd;

	C_CSPlayer*		m_pLocal;
	C_WeaponCSBase*	m_pWeapon;

	Vector3			m_vEnd;

	int				m_iBestIndex;
	float			m_flBestTarget;

	void				ApplyStepSmooth(Vector3& vAim);
	void				ApplyLinearSmooth(Vector3& vAim);
};

#endif // AIMBOT_H
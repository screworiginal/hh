#define _USE_MATH_DEFINES
#include "Math.h"



float Rad2Deg( float x )
{
	return ( x * ( 180.0f / RAD_PI ) );
}

float Deg2Rad( float x )
{
	return ( x * ( RAD_PI / 180.0f ) );
}

void VectorTransform( const Vector3& vSome, const Matrix3x4& vMatrix, Vector3& vOut )
{
	for( auto i = 0; i < 3; i++ )
		vOut[i] = vSome.Dot( vMatrix[i] ) + vMatrix[i][3];
}

void SinCos( float x, float* s, float* c )
{
	__asm
	{
		fld dword ptr[x]
		fsincos
		mov edx, dword ptr[c]
		mov eax, dword ptr[s]
		fstp dword ptr[edx]
		fstp dword ptr[eax]
	}
}

void AngleVectors( const Vector3& angles, Vector3* forward )
{
	float sp, sy, cp, cy;

	SinCos( Deg2Rad( angles.x ), &sp, &cp );
	SinCos( Deg2Rad( angles.y ), &sy, &cy );
	
	if( forward )
	{
		forward->x = cp * cy;
		forward->y = cp * sy;
		forward->z = -sp;
	}
}

void AngleVectors( const Vector3& angles, Vector3* forward, Vector3* right, Vector3* up )
{
	float sr, sp, sy, cr, cp, cy;

	SinCos( Deg2Rad( angles.x ), &sp, &cp );
	SinCos( Deg2Rad( angles.y ), &sy, &cy );
	SinCos( Deg2Rad( angles.z ), &sr, &cr );

	if( forward )
	{
		forward->x = cp * cy;
		forward->y = cp * sy;
		forward->z = -sp;
	}

	if( right )
	{
		right->x = (-1 * sr * sp * cy + -1 * cr * -sy);
		right->y = (-1 * sr * sp * sy + -1 * cr * cy);
		right->z = -1 * sr * cp;
	}

	if( up )
	{
		up->x = (cr * sp * cy + -sr * -sy);
		up->y = (cr * sp * sy + -sr * cy);
		up->z = cr * cp;
	}
}

void VectorAngles( const Vector3& forward, Vector3& angles )
{
	float tmp, yaw, pitch;

	if (forward.y == 0 && forward.x == 0)
	{
		yaw = 0;

		if (forward.z > 0)
			pitch = 270;
		else
			pitch = 90;
	}
	else
	{
		yaw = Rad2Deg( atan2f( forward.y, forward.x ) );

		if (yaw < 0)
			yaw += 360;

		tmp = forward.Length2d( );
		pitch = Rad2Deg( atan2f( -forward.z, tmp ) );

		if (pitch < 0)
			pitch += 360;
	}

	angles[0] = pitch;
	angles[1] = yaw;
	angles[2] = 0;
}

float VectorNormalize( Vector3& v )
{
	float flLength = v.Length( );

	if( !flLength )
		v.Set( );
	else
		v /= flLength;

	return flLength;
}

void AngleNormalize( Vector3& v )
{
	for( auto i = 0; i < 3; i++ )
	{
		if( v[i] < -180.0f ) v[i] += 360.0f;
		if( v[i] >  180.0f ) v[i] -= 360.0f;
	}
}
float ToRadians(float degrees)
{
	return (degrees * (M_PI / 180.0f));
}

float ToDegrees(float radians)
{
	return (radians * (180.0f / M_PI));
}
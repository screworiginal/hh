#include "NetData.h"
#include "Player.h"

void CNetData::GetData( C_CSPlayer* pPlayer )
{
	auto pSlot = &m_Data[pPlayer->GetTickBase( ) % 128];

	pSlot->Set( pPlayer->GetPunchAngle( ) );
}

void CNetData::SetData( C_CSPlayer* pPlayer )
{
	auto pSlot = &m_Data[pPlayer->GetTickBase( ) % 128];

	pPlayer->SetPunchAngle( pSlot->Get( ) );
}
#ifndef MAIN_H
#define MAIN_H

#pragma once

#include "SDK.h"

class CConfig;
class CManager;
class CRenderer;
class CAimbot;
class CAccuracy;
class CNetData;
class CPlayerPred;
class CMenu;
class cMouse;

namespace Main
{
	//
	// interaces
	//
	extern CHLClient*					m_pClient;
	extern CInput*						m_pInput;
	extern CServerData*					m_pServerData;
	extern CClientEntityList*			m_pEntList;
	extern CPrediction*					m_pPrediction;
	extern CGameMovement*				m_pGameMovement;
	extern CEngineClient*				m_pEngine;
	extern CCvar*						m_pCvar;
	extern CModelData*					m_pModelData;
	extern CEngineTrace*				m_pEngineTrace;
	extern CPhysicsSurface*				m_pPhysics;
	extern CPanel*						m_pPanel;
	extern CSurface*					m_pSurface;

	//
	// custom
	//
	extern std::shared_ptr<CConfig>		m_pConfig;
	extern std::shared_ptr<CManager>	m_pManager;
	extern std::shared_ptr<CRenderer>	m_pRenderer;
	extern std::shared_ptr<CAimbot>		m_pAimbot;
	extern std::shared_ptr<CAccuracy>	m_pAccuracy;
	extern std::shared_ptr<CNetData>	m_pNetData;
	extern std::shared_ptr<CPlayerPred>	m_pPlayerPred;
	extern std::shared_ptr<CMenu>		g_pGameGui;
	extern std::shared_ptr<cMouse>      m_pMouse;
	

	//
	// functions
	//
	extern void							Startup( void );

	extern void							Release( void );

	//
	// Returns interface ptr
	//
	extern void*						Get( const std::string& szModule, const std::string& szName, bool bCustom = false );

	//
	// Simple visible check
	//
	extern bool							Visible( const Vector3& vEnd, C_BaseEntity* pEnt = nullptr );


	//
	// World2Screen for esp
	//
	extern bool							WorldToScreen( const Vector3& vPoint, Vector2& vOut );

	//
	// IDA style pattern scan
	//
	extern uintptr_t					PatternScan( const std::string& szModule, const std::string& szPattern );

	extern uintptr_t					GetESI( void );
	extern uintptr_t					GetEDI( void );
}



#endif // MAIN_H
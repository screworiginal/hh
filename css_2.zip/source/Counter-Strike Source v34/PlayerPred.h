#ifndef PLAYERPRED_H
#define PLAYERPRED_H

#pragma once

#include "SDK.h"

class CPlayerPred
{
public:
	void PreFrame( C_CSPlayer* pLocal, CUserCmd* pCmd );
	void PostFrame( C_CSPlayer* pLocal );

private:
	float m_flCurTimeOld;
	float m_flFrameTimeOld;
};

#endif // PLAYERPRED_H
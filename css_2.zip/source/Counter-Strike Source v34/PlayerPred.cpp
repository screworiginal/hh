#include "PlayerPred.h"
#include "Main.h"
#include "Player.h"

void CPlayerPred::PreFrame( C_CSPlayer* pLocal, CUserCmd* pCmd )
{
	m_flCurTimeOld = Main::m_pServerData->curtime;
	m_flFrameTimeOld = Main::m_pServerData->frametime;

	*( CUserCmd** )( pLocal + 0xD60 ) = pCmd;

	Main::m_pServerData->curtime = pLocal->GetTickBase( ) * Main::m_pServerData->interval_per_tick;
	Main::m_pServerData->frametime = Main::m_pServerData->interval_per_tick;

	CMoveData MoveData;

	Main::m_pPrediction->SetupMove( pLocal, pCmd, nullptr, &MoveData );
	Main::m_pGameMovement->ProcessMovement( pLocal, &MoveData );
	Main::m_pPrediction->FinishMove( pLocal, pCmd, &MoveData );
}

void CPlayerPred::PostFrame( C_CSPlayer* pLocal )
{
	*( CUserCmd** )( pLocal + 0xD60 ) = nullptr;

	Main::m_pServerData->curtime = m_flCurTimeOld;
	Main::m_pServerData->frametime = m_flFrameTimeOld;
}

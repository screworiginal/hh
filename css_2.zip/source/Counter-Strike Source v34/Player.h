#ifndef PLAYER_H
#define PLAYER_H

#pragma once

#include "Entity.h"

class C_CSPlayer : public C_BaseEntity
{
public:
	// static
	static C_CSPlayer* GetLocalPlayer( void );

	// C_BaseAnimating
	int				GetHitboxSet( void );		// DT_BaseAnimating->m_nHitboxSet

	// C_BaseCombatCharacter
	C_WeaponCSBase*	GetActiveWeapon( void );	// DT_BaseCombatCharacter->m_hActiveWeapon
	float			GetNextAttack( void );		// DT_BaseCombatCharacter->m_flNextAttack

	// C_BasePlayer
	int				GetFOV( void );				// DT_BasePlayer->m_iFOV
	int				GetFlags( void );			// DT_BasePlayer->m_fFlags
	Vector3			GetPunchAngle( void );		// DT_BasePlayer->m_Local.m_vecPunchAngle
	Vector3			GetViewOffset( void );		// DT_BasePlayer->m_vecViewOffset[0]
	Vector3			GetVelocity( void );		// DT_BasePlayer->m_vecVelocity[0]
	int				GetTickBase( void );		// DT_BasePlayer->m_nTickBase
	int				GetHealth( void );			// DT_BasePlayer->m_iHealth
	bool			IsDead( void );				// DT_BasePlayer->m_lifeState

	Matrix3x4		GetCoordinateFrame( void );	// DT_BasePlayer->m_rgflCoordinateFrame

	// C_CSPlayer
	int				GetArmor( void );			// DT_CSPlayer->m_ArmorValue
	bool			HasHelmet( void );			// DT_CSPlayer->m_bHasHelmet
	int				GetShotsFired( void );		// DT_CSPlayer->m_iShotsFired

	// Custom
	Vector3			GetEyePosition( void );

	bool			GetBonePosition( int iBone, Vector3& vOut );
	bool			GetHitboxPosition( int iHitbox, Vector3& vOut );

	void			SetPunchAngle( const Vector3& vecPunchAngle );
	void			SetTickBase( int nTickBase );
};

FORCEINLINE C_CSPlayer* ToCSPlayer( C_BaseEntity* pEntity )
{
	if( !pEntity || !pEntity->IsPlayer( ) )
		return nullptr;

	return ( C_CSPlayer* )pEntity;
}

#endif // PLAYER_H
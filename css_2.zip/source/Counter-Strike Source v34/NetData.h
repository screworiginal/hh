#ifndef NETDATA_H
#define NETDATA_H

#pragma once

#include "SDK.h"

class CDataSlot
{
public:
	Vector3 Get( void )
	{
		return m_vData;
	}

	void Set( const Vector3& vData )
	{
		m_vData = vData;
	}

private:
	Vector3 m_vData;
};

class CNetData
{
public:
	void		GetData( C_CSPlayer* pPlayer );
	void		SetData( C_CSPlayer* pPlayer );

private:
	CDataSlot	m_Data[128];
};

#endif // NETDATA_H
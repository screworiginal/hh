#include "Main.h"
#include "Player.h"
#include "Weapon.h"
#include "Config.h"
#include "Manager.h"
#include "Renderer.h"
#include "Aimbot.h"
#include "Accuracy.h"
#include "NetData.h"
#include "PlayerPred.h"
#include "Gui.h"
#include <cstdlib>

void DbgPrint( const char* msg, ... )
{
	char format[1024];

	va_list args;

	va_start( args, msg );

	auto len = std::vsprintf( format, msg, args );

	va_end( args );

	format[len + 0] = '\r';
	format[len + 1] = '\n';
	format[len + 2] = '\0';

	OutputDebugStringA( format );
}

namespace Main
{
	CHLClient*					m_pClient = nullptr;
	CInput*						m_pInput = nullptr;
	CServerData*				m_pServerData = nullptr;
	CClientEntityList*			m_pEntList = nullptr;
	CPrediction*				m_pPrediction = nullptr;
	CGameMovement*				m_pGameMovement = nullptr;
	CEngineClient*				m_pEngine = nullptr;
	CCvar*						m_pCvar = nullptr;
	CModelData*					m_pModelData = nullptr;
	CEngineTrace*				m_pEngineTrace = nullptr;
	CPhysicsSurface*			m_pPhysics = nullptr;
	CPanel*						m_pPanel = nullptr;
	CSurface*					m_pSurface = nullptr;


	std::shared_ptr<CHook>		m_pClientHook = nullptr;
	std::shared_ptr<CHook>		m_pPredictionHook = nullptr;
	std::shared_ptr<CHook>		m_pInputHook = nullptr;
	std::shared_ptr<CHook>		m_pPanelHook = nullptr;

	std::shared_ptr<CConfig>	m_pConfig = nullptr;
	std::shared_ptr<CManager>	m_pManager = nullptr;
	std::shared_ptr<CRenderer>	m_pRenderer = nullptr;
	std::shared_ptr<CAimbot>	m_pAimbot = nullptr;
	std::shared_ptr<CAccuracy>	m_pAccuracy = nullptr;
	std::shared_ptr<CNetData>	m_pNetData = nullptr;
	std::shared_ptr<CPlayerPred>m_pPlayerPred = nullptr;
	std::shared_ptr<CMenu>		g_pGameGui = nullptr;
	std::shared_ptr<cMouse>	    m_pMouse = nullptr;

	bool						m_bSendPacket = false;

	CUserCmd* __fastcall Hooked_GetUserCmd(void* ecx, void* edx, int sequence_number)
	{
		return m_pInput->GetUserCmd(sequence_number);
	}

	void TriggerBot(CUserCmd* pCmd)
	{
		if (m_pConfig->m_TriggerbotKey)
		{
			if (!Main::m_pRenderer->IsKeyPressed(Main::m_pConfig->m_TriggerbotKey))
				return;
		}

		if (m_pAimbot->CanHit(pCmd->random_seed, pCmd->viewangles))
			pCmd->buttons |= IN_ATTACK;
	}

	/*if(Main::m_pConfig->m_AimbotKeys)
	{
		if( !Valid( m_iBestIndex ) || !Main::m_pRenderer->IsKeyPressed(Main::m_pConfig->m_AimbotKeys))
			m_iBestIndex = -1;
	}
	else
	{
		if( !Valid( m_iBestIndex ) )
			m_iBestIndex = -1;
	}
}
*/
	void Crosshair()
	{
		auto player = C_CSPlayer::GetLocalPlayer();

		if (!player)
			return;

		int w, h;
		m_pEngine->GetScreenSize(w, h);

		int x = w / 2;
		int y = h / 2;

		if (m_pConfig->m_MiscShowRecoilCrosshair)
		{
			int dx = w / 90;
			int dy = h / 90;

			x -= (dx * player->GetPunchAngle().y);
			y += (dy * player->GetPunchAngle().x);
		}



		if (m_pConfig->m_MiscCrosshair == 1) // Dot
		{
			m_pRenderer->DrawRect(x - 2, y - 2, 4, 4, Color::Black());

			m_pRenderer->DrawRect(x - 1, y - 1, 2, 2, Color::White());
		}
		else if (m_pConfig->m_MiscCrosshair == 2) // Cross
		{
			{
				m_pRenderer->DrawRect(x - 11, y - 1, 23, 3, Color::Black());
				m_pRenderer->DrawRect(x - 1, y - 11, 3, 23, Color::Black());
			}

			m_pRenderer->DrawRect(x - 10, y, 21, 1, Color::White());
			m_pRenderer->DrawRect(x, y - 10, 1, 21, Color::White());
		}
		else if (m_pConfig->m_MiscCrosshair == 3) // Swastika
		{
			{
				m_pRenderer->DrawRect(x - 11, y - 1, 23, 3, Color::Black());
				m_pRenderer->DrawRect(x - 1, y - 11, 3, 23, Color::Black());

				m_pRenderer->DrawRect(x - 1, y - 11, 13, 3, Color::Black());  // top -> left
				m_pRenderer->DrawRect(x - 11, y - 11, 3, 11, Color::Black());  // top -> bottom
				m_pRenderer->DrawRect(x + 9, y, 3, 12, Color::Black());  // right -> bottom
				m_pRenderer->DrawRect(x - 11, y + 9, 11, 3, Color::Black());  // bottom -> left
			}

			m_pRenderer->DrawRect(x - 10, y, 21, 1, Color::White());
			m_pRenderer->DrawRect(x, y - 10, 1, 21, Color::White());

			m_pRenderer->DrawRect(x, y - 10, 11, 1, Color::White()); // top -> left
			m_pRenderer->DrawRect(x - 10, y - 10, 1, 10, Color::White()); // top -> bottom
			m_pRenderer->DrawRect(x + 10, y, 1, 11, Color::White()); // right -> bottom
			m_pRenderer->DrawRect(x - 10, y + 10, 10, 1, Color::White()); // bottom -> left
		}
		if (m_pConfig->m_MiscCrosshair == 4) // Dot
		{
			m_pRenderer->DrawRect(x - 2, y - 2, 4, 4, Color::Black());

			m_pRenderer->DrawRect(x - 1, y - 1, 2, 2, Color::Rainbow());
		}
		else if (m_pConfig->m_MiscCrosshair == 5) // Cross
		{
			{
				m_pRenderer->DrawRect(x - 11, y - 1, 23, 3, Color::Black());
				m_pRenderer->DrawRect(x - 1, y - 11, 3, 23, Color::Black());
			}

			m_pRenderer->DrawRect(x - 10, y, 21, 1, Color::Rainbow());
			m_pRenderer->DrawRect(x, y - 10, 1, 21, Color::Rainbow());
		}
		else if (m_pConfig->m_MiscCrosshair == 6) // Swastika
		{
			{
				m_pRenderer->DrawRect(x - 11, y - 1, 23, 3, Color::Black());
				m_pRenderer->DrawRect(x - 1, y - 11, 3, 23, Color::Black());

				m_pRenderer->DrawRect(x - 1, y - 11, 13, 3, Color::Black());  // top -> left
				m_pRenderer->DrawRect(x - 11, y - 11, 3, 11, Color::Black());  // top -> bottom
				m_pRenderer->DrawRect(x + 9, y, 3, 12, Color::Black());  // right -> bottom
				m_pRenderer->DrawRect(x - 11, y + 9, 11, 3, Color::Black());  // bottom -> left
			}

			m_pRenderer->DrawRect(x - 10, y, 21, 1, Color::Rainbow());
			m_pRenderer->DrawRect(x, y - 10, 1, 21, Color::Rainbow());

			m_pRenderer->DrawRect(x, y - 10, 11, 1, Color::Rainbow()); // top -> left
			m_pRenderer->DrawRect(x - 10, y - 10, 1, 10, Color::Rainbow()); // top -> bottom
			m_pRenderer->DrawRect(x + 10, y, 1, 11, Color::Rainbow()); // right -> bottom
			m_pRenderer->DrawRect(x - 10, y + 10, 10, 1, Color::Rainbow()); // bottom -> left
		}

	}
	enum MoveType_t
	{
		MOVETYPE_NONE = 0,
		MOVETYPE_ISOMETRIC,
		MOVETYPE_WALK,
		MOVETYPE_STEP,
		MOVETYPE_FLY,
		MOVETYPE_FLYGRAVITY,
		MOVETYPE_VPHYSICS,
		MOVETYPE_PUSH,
		MOVETYPE_NOCLIP,
		MOVETYPE_LADDER,
		MOVETYPE_OBSERVER,
		MOVETYPE_CUSTOM,
		MOVETYPE_LAST = MOVETYPE_CUSTOM,
		MOVETYPE_MAX_BITS = 4
	};

	void AntiAim(CUserCmd* cmd, C_CSPlayer* player, C_WeaponCSBase* weapon)
	{
		if (player->m_MoveType() == MOVETYPE_LADDER || player->m_MoveType() == MOVETYPE_NOCLIP)
			return;

		if ((cmd->buttons & IN_ATTACK) && weapon->CanFire())
			return;


		if (m_pConfig->m_aapitch == 1) // Up
		{
				cmd->viewangles.x = -89.0f;
			}
		
		else if (m_pConfig->m_aapitch == 2) // Down
		{
			cmd->viewangles.x = 89.0f;
	
			}
		
		else if (m_pConfig->m_aapitch == 3) // Emotion Up
		{
             cmd->viewangles.x = -70.0f;
			}
			
			
		
		else if (m_pConfig->m_aapitch == 4) // Emotion Down
			{
				cmd->viewangles.x = 70.0f;
			}

		
		else if (m_pConfig->m_aapitch == 5) // Fake Up

			{
				cmd->viewangles.x = 180.0f;
			}
		

		if (m_pConfig->m_aayaw == 1) // Backwards
		{
			cmd->viewangles.y += 180.0f;
		}
		else if (m_pConfig->m_aayaw == 2) // Fake Forward
		{
			static int choked_tick_count = 0;

			if (choked_tick_count == 0)
			{
				choked_tick_count = m_pConfig->m_chokedpackets;

				m_bSendPacket = true;
			}
			else
			{
				choked_tick_count--;

				m_bSendPacket = false;

				cmd->viewangles.y += 180.0f;
			}
		}
		else if (m_pConfig->m_aayaw == 3) // Sideways Left
		{
			cmd->viewangles.y += 90.0f;

		}
		else if (m_pConfig->m_aayaw == 4) // Sideways Right
		{
			cmd->viewangles.y -= 90.0f;
		}
		else if (m_pConfig->m_aayaw == 5) // Fake Sideways Left
		{
			static int choked_tick_count = 0;

			if (choked_tick_count == 0)
			{
				choked_tick_count = m_pConfig->m_chokedpackets;

				m_bSendPacket = true;

				cmd->viewangles.y += 90.0f;
			}
			else
			{
				choked_tick_count--;

				m_bSendPacket = false;

				cmd->viewangles.y -= 90.0f;
			}
		}
		else if (m_pConfig->m_aayaw == 6) // Fake Sideways Right
		{
			static int choked_tick_count = 0;

			if (choked_tick_count == 0)
			{
				choked_tick_count = m_pConfig->m_chokedpackets;

				m_bSendPacket = true;

				cmd->viewangles.y -= 90.0f;
			}
			else
			{
				choked_tick_count--;

				m_bSendPacket = false;

				cmd->viewangles.y += 90.0f;
			}
		}
		else if (m_pConfig->m_aayaw == 7) // Slow Spin
		{
			static float yaw = 0.0f;

			yaw += 10.0f;

			cmd->viewangles.y += yaw;
			if (yaw > 360.0f)
				yaw = 0.0f;
		}
		else if (m_pConfig->m_aayaw == 8) // Fast Spin
		{
			static float yaw = 0.0f;

			yaw += 45.0f;

			cmd->viewangles.y += yaw;
			if (yaw > 360.0f)
				yaw = 0.0f;
		}
		else if (m_pConfig->m_aayaw == 9) // Jitter
		{
			int type = cmd->command_number % 3;

			if (type == 1)
			{
				cmd->viewangles.y -= 160.0f;
				m_bSendPacket = true;
			}
			else if (type == 2)
			{
				cmd->viewangles.y -= 200.0f;
				m_bSendPacket = false;
			}
		}
	}


	void MovementFix(CUserCmd* cmd, const Vector3& va, bool aa)
	{
		float yaw, speed;

		Vector3& move = *(Vector3*)&cmd->forwardmove;

		speed = move.Length();

		yaw = ToDegrees(atan2(move.y, move.x));
		yaw = ToRadians(cmd->viewangles.y - va.y + yaw);

		
		if (aa)
			move.x = -cos(yaw) * speed;
		else
			move.x = cos(yaw) * speed;

		move.y = sin(yaw) * speed;
	}

	void __fastcall CreateMoveFrame(void* ecx, void* edx, int sequence_number, float input_sample_frametime, bool active)
	{
		
		m_pClientHook->GetMethod<CreateMoveFn>(Index::CreateMove)(ecx, sequence_number, input_sample_frametime, active);

		auto pCmd = m_pInput->GetUserCmd(sequence_number);

		if (!pCmd)
			return;

		auto pLocal = C_CSPlayer::GetLocalPlayer();

		if (!pLocal)
			return;

		if (pLocal->IsDead())
			return;

		auto player = C_CSPlayer::GetLocalPlayer();
		auto va = pCmd->viewangles;
		auto weapon = player->GetActiveWeapon();
		if (pCmd->buttons & IN_ATTACK && !weapon->CanFire())
			pCmd->viewangles = va;

		if (m_pConfig->m_MiscBunnyHop)
		{
			//
			// Credits: how02
			//
			static bool bLastJumped = false;
			static bool bShouldFake = false;

			if (!bLastJumped && bShouldFake)
			{
				bShouldFake = false;
				pCmd->buttons |= IN_JUMP;
			}
			else if (pCmd->buttons & IN_JUMP)
			{
				if (pLocal->GetFlags() & FL_ONGROUND)
				{
					bLastJumped = true;
					bShouldFake = true;
				}
				else
				{
					pCmd->buttons &= ~IN_JUMP;
					bLastJumped = false;
				}
			}
			else
			{
				bLastJumped = false;
				bShouldFake = false;
			}
		}
		
		
		m_pPlayerPred->PreFrame(pLocal, pCmd);

		auto pWeapon = pLocal->GetActiveWeapon();
		
		
		if (pWeapon)
		{
			
			if (!pWeapon->IsMelee() && pWeapon->GetClip1())
			{
				auto player = C_CSPlayer::GetLocalPlayer();
				auto va = pCmd->viewangles;
				auto weapon = player->GetActiveWeapon();
				Vector3 viewangles = pCmd->viewangles;
				float forwardmove = pCmd->forwardmove;
				float sidemove = pCmd->sidemove;
				

				if (m_pConfig->m_AimbotActive)
					m_pAimbot->Execute(pCmd);

				if (m_pConfig->m_TriggerbotActive)
					TriggerBot(pCmd);
				if (m_pConfig->m_aapitch || m_pConfig->m_aayaw)
					AntiAim(pCmd, player, weapon);
				

				float fServerTime = pLocal->GetTickBase() * m_pServerData->interval_per_tick;
				float fNextAttack = pLocal->GetNextAttack();

				bool bBulletTime = true;
				if (fNextAttack > fServerTime)
					bBulletTime = false;
				
				
			
				if (pCmd->buttons & IN_ATTACK)
				{
					
					if (pWeapon->CanFire())
					{
						if (m_pConfig->m_AimbotPSilent)
							m_bSendPacket = false;

						if (m_pConfig->m_RemSpread)
							m_pAccuracy->ApplySpreadFix(pCmd);

						if (m_pConfig->m_RemRecoil)
							m_pAccuracy->ApplyRecoilFix(pCmd);
					}
					else
					{
						if (m_pConfig->m_AimbotPSilent)
							m_bSendPacket = true;

						pCmd->viewangles = viewangles;
						pCmd->forwardmove = forwardmove;
						pCmd->sidemove = sidemove;
						{
						}
						
					}
				}
				

				MovementFix(pCmd, va, m_pConfig->m_aapitch == 5);
				//MovementFix(pCmd, viewangles); xd
			}
		}

		m_pPlayerPred->PostFrame(pLocal);
	}


	void __declspec(naked) __fastcall Hooked_CreateMove(void* ecx, void* edx, int sequence_number, float input_sample_frametime, bool active)
	{
		__asm
		{
			push    ebp
			mov     ebp, esp

			mov     m_bSendPacket, bl

			movzx	eax, active
			push	eax
			mov		eax, input_sample_frametime
			push	eax
			mov		eax, sequence_number
			push	eax
			call    CreateMoveFrame

			mov     bl, m_bSendPacket

			mov     esp, ebp
			pop     ebp

			retn    0xC
		}
	}

	void __fastcall Hooked_FrameStageNotify(void* ecx, void* edx, ClientFrameStage_t curStage)
	{
		Vector3* pPunchLocal = nullptr;
		Vector3 vPunchReal;

		if (m_pConfig->m_RemVisualRecoil)
		{
			auto pLocal = C_CSPlayer::GetLocalPlayer();

			if (curStage == FRAME_RENDER_START)
			{
				if (pLocal)
				{
					static auto var = m_pManager->Get("DT_BasePlayer", "m_vecPunchAngle");

					pPunchLocal = (Vector3*)(pLocal + var);

					if (pPunchLocal)
					{
						vPunchReal = *pPunchLocal;

						pPunchLocal->Set();
					}
				}
			}
		}

		m_pClientHook->GetMethod<FrameStageNotifyFn>(Index::FrameStageNotify)(ecx, curStage);

		if (pPunchLocal)
			*pPunchLocal = vPunchReal;

		if (curStage == FRAME_NET_UPDATE_END)
		{
			auto pLocal = C_CSPlayer::GetLocalPlayer();

			if (pLocal)
			{
				m_pNetData->SetData(pLocal);

				static auto m_flFlashMaxAlpha = m_pManager->Get("DT_CSPlayer", "m_flFlashMaxAlpha");
				static auto m_flFlashDuration = m_pManager->Get("DT_CSPlayer", "m_flFlashDuration");

				static auto flFlashMaxAlpha = 255.0f;
				static auto flFlashDuration = 5.865356f;

				if (m_pConfig->m_RemFlash)
				{
					*(float*)(pLocal + m_flFlashMaxAlpha) = 0.0f;
					*(float*)(pLocal + m_flFlashDuration) = 0.0f;
				}
				else
				{
					*(float*)(pLocal + m_flFlashMaxAlpha) = flFlashMaxAlpha;
					*(float*)(pLocal + m_flFlashDuration) = flFlashDuration;
				}

				auto cl_pitchup = m_pCvar->FindVar("cl_pitchup");
				auto cl_pitchdown = m_pCvar->FindVar("cl_pitchdown");

				if (m_pConfig->m_RemBackflip)
				{
					cl_pitchup->SetValue(900);
					cl_pitchdown->SetValue(900);
				}
				else
				{
					cl_pitchup->SetValue(89);
					cl_pitchdown->SetValue(89);
				}
			}
		}
	}

	void __fastcall Hooked_RunCommand(void* ecx, void* edx, C_CSPlayer* player, CUserCmd* ucmd, CMoveHelper* moveHelper)
	{
		m_pPredictionHook->GetMethod<RunCommandFn>(Index::RunCommand)(ecx, player, ucmd, moveHelper);

		m_pNetData->GetData(player);
	}

	void __fastcall Hooked_Update(void* ecx, void* edx, bool received_new_world_update, bool validframe, int incoming_acknowledged, int outgoing_command)
	{
		m_pPredictionHook->GetMethod<UpdateFn>(Index::Update)(ecx, true, validframe, incoming_acknowledged, outgoing_command);
	}

	bool IsGoodPanel(VPANEL vguiPanel)
	{
		static VPANEL MatSystemTopPanel = 0;

		if (!MatSystemTopPanel)
		{
			const char* pName = m_pPanel->GetName(vguiPanel);

			if (std::strcmp(pName, "MatSystemTopPanel") == 0)
			{
				MatSystemTopPanel = vguiPanel;
				return true;
			}
		}

		return (vguiPanel == MatSystemTopPanel);
	}

	//
	// Credits: dude719
	//
	void DrawBox(Vector3* pointList, const Color& color)
	{
		Vector2 vStart, vEnd;

		for (auto i = 0; i < 3; i++)
		{
			if (WorldToScreen(pointList[i], vStart))
			{
				if (WorldToScreen(pointList[i + 1], vEnd))
					m_pRenderer->DrawLine(vStart, vEnd, color);
			}
		}

		if (WorldToScreen(pointList[0], vStart))
		{
			if (WorldToScreen(pointList[3], vEnd))
				m_pRenderer->DrawLine(vStart, vEnd, color);
		}

		for (int i = 4; i < 7; i++)
		{
			if (WorldToScreen(pointList[i], vStart))
			{
				if (WorldToScreen(pointList[i + 1], vEnd))
					m_pRenderer->DrawLine(vStart, vEnd, color);
			}
		}

		if (WorldToScreen(pointList[4], vStart))
		{
			if (WorldToScreen(pointList[7], vEnd))
				m_pRenderer->DrawLine(vStart, vEnd, color);
		}

		if (WorldToScreen(pointList[0], vStart))
		{
			if (WorldToScreen(pointList[6], vEnd))
				m_pRenderer->DrawLine(vStart, vEnd, color);
		}

		if (WorldToScreen(pointList[1], vStart))
		{
			if (WorldToScreen(pointList[5], vEnd))
				m_pRenderer->DrawLine(vStart, vEnd, color);
		}

		if (WorldToScreen(pointList[2], vStart))
		{
			if (WorldToScreen(pointList[4], vEnd))
				m_pRenderer->DrawLine(vStart, vEnd, color);
		}

		if (WorldToScreen(pointList[3], vStart))
		{
			if (WorldToScreen(pointList[7], vEnd))
				m_pRenderer->DrawLine(vStart, vEnd, color);
		}
	}

	void FrameHitbox(C_CSPlayer* pPlayer, int iHitbox)
	{
		const model_t* pModel = pPlayer->GetModel();

		if (!pModel)
			return;

		studiohdr_t* pStudioHdr = m_pModelData->GetStudioModel(pModel);

		if (!pStudioHdr)
			return;

		mstudiohitboxset_t* pSet = pStudioHdr->GetHitboxSet(pPlayer->GetHitboxSet());

		if (!pSet)
			return;

		mstudiobbox_t* pBox = pSet->GetHitbox(iHitbox);

		if (!pBox)
			return;

		Matrix3x4 vMatrix[MAXSTUDIOBONES];

		if (!pPlayer->SetupBones(vMatrix, MAXSTUDIOBONES, BONE_USED_BY_HITBOX, m_pServerData->curtime))
			return;

		Vector3 vMin = pBox->bbmin;
		Vector3 vMax = pBox->bbmax;

		Vector3 vPointList[] =
		{
			Vector3(vMin.x, vMin.y, vMin.z),
			Vector3(vMin.x, vMax.y, vMin.z),
			Vector3(vMax.x, vMax.y, vMin.z),
			Vector3(vMax.x, vMin.y, vMin.z),
			Vector3(vMax.x, vMax.y, vMax.z),
			Vector3(vMin.x, vMax.y, vMax.z),
			Vector3(vMin.x, vMin.y, vMax.z),
			Vector3(vMax.x, vMin.y, vMax.z)
		};

		Vector3 vTransformed[8];

		for (auto i = 0; i < 8; i++)
			VectorTransform(vPointList[i], vMatrix[pBox->bone], vTransformed[i]);

		DrawBox(vTransformed, Color::White());
	}

	void FramePlayer(C_CSPlayer* pPlayer, const Color& color, C_BaseEntity* pEntity)
	{
		auto pLocal = C_CSPlayer::GetLocalPlayer();

		if (!pLocal)
			return;

		if (m_pConfig->m_EspBox && pEntity->GetTeamNumber() == pLocal->GetTeamNumber())
			return;

		const Matrix3x4& vMatrix = pPlayer->GetCoordinateFrame();

		Vector3 vOrigin(vMatrix[0][3], vMatrix[1][3], vMatrix[2][3]);

		if (vOrigin.IsZero())
			return;

		Vector3 vMin = pPlayer->GetMins();
		Vector3 vMax = pPlayer->GetMaxs();

		vMax.z += 10.0f;

		Vector3 vPointList[] =
		{
			Vector3(vMin.x, vMin.y, vMin.z),
			Vector3(vMin.x, vMax.y, vMin.z),
			Vector3(vMax.x, vMax.y, vMin.z),
			Vector3(vMax.x, vMin.y, vMin.z),
			Vector3(vMax.x, vMax.y, vMax.z),
			Vector3(vMin.x, vMax.y, vMax.z),
			Vector3(vMin.x, vMin.y, vMax.z),
			Vector3(vMax.x, vMin.y, vMax.z)
		};

		Vector3 vTransformed[8];

		for (auto i = 0; i < 8; i++)
			VectorTransform(vPointList[i], vMatrix, vTransformed[i]);

		Vector2 flb, brt, blb, frt, frb, brb, blt, flt;

		if (!WorldToScreen(vTransformed[3], flb) ||
			!WorldToScreen(vTransformed[0], blb) ||
			!WorldToScreen(vTransformed[2], frb) ||
			!WorldToScreen(vTransformed[6], blt) ||
			!WorldToScreen(vTransformed[5], brt) ||
			!WorldToScreen(vTransformed[4], frt) ||
			!WorldToScreen(vTransformed[1], brb) ||
			!WorldToScreen(vTransformed[7], flt))
			return;

		Vector2 arr[] = { flb, brt, blb, frt, frb, brb, blt, flt };

		float left = flb.x;
		float top = flb.y;
		float right = flb.x;
		float bottom = flb.y;

		for (auto i = 0; i < 8; i++)
		{
			if (left > arr[i].x)
				left = arr[i].x;
			if (top < arr[i].y)
				top = arr[i].y;
			if (right < arr[i].x)
				right = arr[i].x;
			if (bottom > arr[i].y)
				bottom = arr[i].y;
		}

		float x = left;
		float y = bottom;

		float w = right - left;
		float h = top - bottom;

		if (m_pConfig->m_EspBox == 1)
		{
			m_pRenderer->DrawFrameBox(x, y, w, h, 1, color);
		}

		if (m_pConfig->m_EspBox == 2)
		{
			m_pRenderer->DrawFrameBoxOut(x, y, w, h, 1, color, Color::Black());
		}
		int pad_h = 0;
		if (m_pConfig->m_EspName)
		{
			player_info_t data;

			if (m_pEngine->GetPlayerInfo(pPlayer->GetIndex(), &data))
				m_pRenderer->DrawText(x + w + 2, y - 16, TEXT_CENTER_H, Color::Rainbow(), data.name);
		}

		auto iPad = 0;

		if (m_pConfig->m_EspHealth == 1) //Text
		{
			m_pRenderer->DrawText(x + w + 1, y + iPad, TEXT_LEFT, Color::Red(), "  %i", pPlayer->GetHealth());
			iPad += 14;
		}
		if (m_pConfig->m_EspHealth == 2) //Bar
		{
			int health = pPlayer->GetHealth();

			int size_h = (int)std::round(((h)* health) / 100);
			int real_h = (h)-size_h;

			m_pRenderer->DrawRect(x - 6, y - 1, 4, h + 3, Color(0, 0, 0));
			m_pRenderer->DrawRect(x - 5, y + real_h, 2, size_h, Color(255 - (pPlayer->GetHealth() * 2.55f), pPlayer->GetHealth() * 2.55f, 0));
		}

		if (m_pConfig->m_EspArmor == 1) //Text
		{
			m_pRenderer->DrawText(x + w + 1, y + iPad, TEXT_LEFT, Color::Cyan(), "  %i", pPlayer->GetArmor());
			iPad += 14;
		}
		if (m_pConfig->m_EspArmor == 2) // Bar
		{
			int armor = pPlayer->GetArmor();

			if (armor > 100)
				armor = 100;

			int size_h = (int)std::round(((h + 1) * armor) / 100);
			int real_h = (h + 1) - size_h;

			m_pRenderer->DrawRect(x + w + 3, y - 1, 4, h + 3, Color::Black());
			m_pRenderer->DrawRect(x + w + 4, y + real_h, 2, size_h, Color(180, 180, 180));
		}
		if (m_pConfig->m_EspDefuse)
		{
			if (pEntity->IsDefusing())
				m_pRenderer->DrawText(x + w / 2, y - 16, TEXT_CENTER_H, Color::Cyan(), "DEFUSING!");
		}
		if (m_pConfig->m_EspBone)
		{
			const model_t* pModel = pPlayer->GetModel();

			if (pModel)
			{
				studiohdr_t* pStudioHdr = m_pModelData->GetStudioModel(pModel);

				if (pStudioHdr)
				{
					for (auto i = 0; i < pStudioHdr->numbones; i++)
					{
						mstudiobone_t* pBone = pStudioHdr->GetBone(i);

						if (!pBone)
							continue;

						if (!(pBone->flags & BONE_USED_BY_HITBOX))
							continue;

						if (pBone->parent == -1)
							continue;

						Vector3 vBone, vParent;
						Vector2 vBoneS, vParentS;

						pPlayer->GetBonePosition(i, vBone);
						pPlayer->GetBonePosition(pBone->parent, vParent);

						if (WorldToScreen(vBone, vBoneS) && WorldToScreen(vParent, vParentS))
							m_pRenderer->DrawLine(vBoneS, vParentS, Color::Yellow());
					}
				}
			}
		}

		if (m_pConfig->m_EspHitbox)
		{
			const model_t* pModel = pPlayer->GetModel();

			if (pModel)
			{
				studiohdr_t* pStudioHdr = m_pModelData->GetStudioModel(pModel);

				if (pStudioHdr)
				{
					mstudiohitboxset_t* pSet = pStudioHdr->GetHitboxSet(pPlayer->GetHitboxSet());

					if (pSet)
					{
						for (auto i = 0; i < pSet->numhitboxes; i++)
							FrameHitbox(pPlayer, i);
					}
				}
			}
		}




		if (m_pConfig->m_EspWeapon)
		{
			auto pWeapon = pPlayer->GetActiveWeapon();

			if (pWeapon)
			{
				auto pName = pWeapon->GetName();

				if (pName)
				{
					m_pRenderer->DrawText(x + w + 2, y + iPad, TEXT_LEFT, Color::Yellow(), "%s", (pName + 7));
					iPad += 14;
				}
			}
		}
	}


	void FrameESP( void )
	{
		auto pLocal = C_CSPlayer::GetLocalPlayer( );

		if( !pLocal )
			return;

		auto nSize = m_pEngine->GetMaxClients( );

		for( auto i = 1; i <= nSize; i++ )
		{
			auto pEntity = m_pEntList->GetClientEntity( i );

			if( !pEntity )
				continue;

			if( !pEntity->IsPlayer( ) )
				continue;

			auto pPlayer = ( C_CSPlayer* )pEntity;

			if( pPlayer == pLocal )
				continue;

			if( pPlayer->IsDead( ) )
				continue;

			if( pPlayer->IsDormant( ) )
				continue;

			Color color = Color::White( );
			
			Vector3 vHead;

			if( !pPlayer->GetHitboxPosition( 12, vHead ) )
				continue;

			if( pPlayer->GetTeamNumber( ) == 2 ) // t
			{
				color = Color::Red( );

				if( m_pConfig->m_EspVisible && Visible( vHead, pEntity ) )
					color = Color::Green( );
			}
			else if( pPlayer->GetTeamNumber( ) == 3 ) // ct
			{
				color = Color::Cyan( );

				if( m_pConfig->m_EspVisible && Visible( vHead, pEntity ) )
					color = Color::Green( );
			}

			FramePlayer( pPlayer, color, pEntity);
		}
	}

	void __fastcall Hooked_PaintTraverse( void* ecx, void* edx, VPANEL vguiPanel, bool forceRepaint, bool allowForce )
	{
		m_pPanelHook->GetMethod<PaintTraverseFn>( Index::PaintTraverse )( ecx, vguiPanel, forceRepaint, allowForce );

		if( IsGoodPanel( vguiPanel ) )
		{
			if( m_pConfig->m_EspActive )
				FrameESP( );


			g_pGameGui->DrawMenu();
			
			if (m_pConfig->m_MiscCrosshair)
				Crosshair();

			m_pRenderer->DrawText( 5, 5, TEXT_LEFT, Color::Rainbow( ), "" );
		}
	}

	void Startup( void )
	{
		m_pClient			= ( CHLClient* )			Get( "client.dll", "VClient" );
		m_pInput			= **( CInput*** )			( ( *( uintptr_t** )m_pClient )[11] + 0x2 );
		m_pServerData		= **( CServerData*** )		( ( *( uintptr_t** )m_pClient )[0] + 0x2F );
		m_pEntList			= ( CClientEntityList* )	Get( "client.dll", "VClientEntityList" );
		m_pPrediction		= ( CPrediction* )			Get( "client.dll", "VClientPrediction" );
		m_pGameMovement		= ( CGameMovement* )		Get( "client.dll", "GameMovement" );
		m_pEngine			= ( CEngineClient* )		Get( "engine.dll", "VEngineClient" );
		m_pCvar				= ( CCvar* )				Get( "engine.dll", "VEngineCvar003", true );
		m_pModelData		= ( CModelData* )			Get( "engine.dll", "VModelInfoClient" );
		m_pEngineTrace		= ( CEngineTrace* )			Get( "engine.dll", "EngineTraceClient" );
		m_pPhysics			= ( CPhysicsSurface* )		Get( "vphysics.dll", "VPhysicsSurfaceProps" );
		m_pPanel			= ( CPanel* )				Get( "vgui2.dll", "VGUI_Panel" );
		m_pSurface			= ( CSurface* )				Get( "vguimatsurface.dll", "VGUI_Surface031", true );

		m_pConfig			= std::shared_ptr<CConfig>( new CConfig );
		m_pManager			= std::shared_ptr<CManager>( new CManager );
		m_pRenderer			= std::shared_ptr<CRenderer>( new CRenderer );
		m_pAimbot			= std::shared_ptr<CAimbot>( new CAimbot );
		m_pAccuracy			= std::shared_ptr<CAccuracy>( new CAccuracy );
		m_pNetData			= std::shared_ptr<CNetData>( new CNetData );
		m_pPlayerPred		= std::shared_ptr<CPlayerPred>( new CPlayerPred );
		g_pGameGui = std::shared_ptr<CMenu>( new CMenu);
		m_pMouse = std::shared_ptr<cMouse>(new cMouse);

		m_pClientHook		= std::shared_ptr<CHook>( new CHook( m_pClient ) );
		m_pPredictionHook	= std::shared_ptr<CHook>( new CHook( m_pPrediction ) );
		m_pInputHook		= std::shared_ptr<CHook>( new CHook( m_pInput ) );
		m_pPanelHook		= std::shared_ptr<CHook>( new CHook( m_pPanel ) );

		m_pClientHook->HookMethod( &Hooked_CreateMove, Index::CreateMove );
		m_pClientHook->HookMethod( &Hooked_FrameStageNotify, Index::FrameStageNotify );
		m_pPredictionHook->HookMethod( &Hooked_RunCommand, Index::RunCommand );
		m_pPredictionHook->HookMethod( &Hooked_Update, Index::Update );
		m_pInputHook->HookMethod( &Hooked_GetUserCmd, Index::GetUserCmd );
		m_pPanelHook->HookMethod( &Hooked_PaintTraverse, Index::PaintTraverse );
	}

	void Release( void )
	{
		SAFE_RESET( m_pClientHook );
		SAFE_RESET( m_pPredictionHook );
		SAFE_RESET( m_pInputHook );
		SAFE_RESET( m_pPanelHook );

		SAFE_RESET( m_pConfig );
		SAFE_RESET( m_pManager );
		SAFE_RESET( m_pRenderer );
		SAFE_RESET( m_pAimbot );
		SAFE_RESET( m_pAccuracy );
		SAFE_RESET( m_pNetData );
		SAFE_RESET( m_pPlayerPred );
		SAFE_RESET(g_pGameGui);
		SAFE_RESET( m_pMouse );
	}

	void* Get( const std::string& szModule, const std::string& szName, bool bCustom )
	{
		auto hModule = GetModuleHandleA( szModule.c_str( ) );

		if( !hModule )
			return nullptr;

		auto pCreateFn = ( CreateInterfaceFn )GetProcAddress( hModule, "CreateInterface" );

		if( !pCreateFn )
			return nullptr;

		if( bCustom )
			return pCreateFn( szName.c_str( ), nullptr );

		char szFormat[1024];

		for( auto i = 0; i < 1000; i++ )
		{
			std::sprintf( szFormat, "%s%03i", szName.c_str( ), i );

			auto pData = pCreateFn( szFormat, nullptr );

			if( pData )
				return pData;
		}

		return nullptr;
	}

	bool Visible( const Vector3& vEnd, C_BaseEntity* pEnt )
	{
		auto pLocal = C_CSPlayer::GetLocalPlayer( );

		if( !pLocal )
			return false;

		trace_t tr;
		Ray_t ray;

		CTraceFilterSimple trace( pLocal );

		ray.Init( pLocal->GetEyePosition( ), vEnd );

		m_pEngineTrace->TraceRay( ray, 0x4600400B, &trace, &tr );

		if( pEnt )
			return ( tr.fraction == 1.0f || tr.m_pEnt == pEnt );

		return ( tr.fraction == 1.0f );
	}
	
	bool WorldToScreen( const Vector3& vPoint, Vector2& vOut )
	{
		auto vMatrix = m_pEngine->WorldToScreenMatrix( );

		vOut[0] = vMatrix.m[0][0] * vPoint[0] + vMatrix.m[0][1] * vPoint[1] + vMatrix.m[0][2] * vPoint[2] + vMatrix.m[0][3];
		vOut[1] = vMatrix.m[1][0] * vPoint[0] + vMatrix.m[1][1] * vPoint[1] + vMatrix.m[1][2] * vPoint[2] + vMatrix.m[1][3];

		auto w = vMatrix.m[3][0] * vPoint[0] + vMatrix.m[3][1] * vPoint[1] + vMatrix.m[3][2] * vPoint[2] + vMatrix.m[3][3];

		if( w < 0.01f )
			return false;

		auto invw = 1.0f / w;

		vOut[0] *= invw;
		vOut[1] *= invw;

		int width, height;

		m_pEngine->GetScreenSize( width, height );

		auto x = ( float )( width / 2 );
		auto y = ( float )( height / 2 );

		x += 0.5f * vOut[0] * width + 0.5f;
		y -= 0.5f * vOut[1] * height + 0.5f;

		vOut[0] = x;
		vOut[1] = y;

		return true;
	}

	//
	// Credits: learn_more
	//
	#ifndef IsInRange
		#define IsInRange(x, a, b) (x >= a && x <= b)
	#endif

	#ifndef GetBits
		#define GetBits(x) (IsInRange(x, '0', '9') ? (x - '0') : ((x&(~0x20)) - 'A' + 0xA))
	#endif

	#ifndef GetByte
		#define GetByte(x) (GetBits(x[0]) << 4 | GetBits(x[1]))
	#endif

	uintptr_t PatternScan( const std::string& szModule, const std::string& szPattern )
	{
		auto hModule = GetModuleHandleA( szModule.c_str( ) );

		if( !hModule )
			return 0;

		PIMAGE_DOS_HEADER DosHeader = ( PIMAGE_DOS_HEADER )hModule;
		PIMAGE_NT_HEADERS NtHeaders;

		PCHAR NtHeaderPtr;

		if( DosHeader->e_magic != IMAGE_DOS_SIGNATURE )
			return 0;

		NtHeaderPtr = ( ( PCHAR )hModule ) + DosHeader->e_lfanew;
		NtHeaders = ( PIMAGE_NT_HEADERS )NtHeaderPtr;

		if( NtHeaders->Signature != IMAGE_NT_SIGNATURE )
			return 0;

		auto pScanStart = ( const PBYTE )( hModule );
		auto pScanEnd = ( const PBYTE )( hModule + NtHeaders->OptionalHeader.SizeOfImage );

		PBYTE pFirstMatch = nullptr;
		auto pByteArray = ( PBYTE )szPattern.c_str( );

		for( auto pCurrent = pScanStart; pCurrent < pScanEnd; ++pCurrent )
		{
			if( *( PBYTE )pByteArray == ( BYTE )'\?' || *pCurrent == GetByte( pByteArray ) )
			{
				if( !pFirstMatch )
					pFirstMatch = pCurrent;

				if( !pByteArray[2] )
					return ( uintptr_t )pFirstMatch;

				pByteArray += ( *( PWORD )pByteArray == ( WORD )'\?\?' || *( PBYTE )pByteArray != ( BYTE )'\?' ) ? 3 : 2;

				if( !*pByteArray )
					return ( uintptr_t )pFirstMatch;
			}
			else if( pFirstMatch )
			{
				pCurrent = pFirstMatch;
				pByteArray = ( PBYTE )szPattern.c_str( );
				pFirstMatch = nullptr;
			}
		}

		return 0;
	}

	__declspec( naked ) uintptr_t GetESI( void )
	{
		__asm
		{
			mov eax, esi
			retn
		}
	}

	__declspec( naked ) uintptr_t GetEDI( void )
	{
		__asm
		{
			mov eax, edi
			retn
		}
	}
}


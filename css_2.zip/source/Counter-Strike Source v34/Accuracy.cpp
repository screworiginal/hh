#include "Accuracy.h"
#include "Main.h"
#include "Player.h"
#include "Weapon.h"
#include "checksum_md5.hpp"

CAccuracy::CAccuracy( void )
{
	auto hModule = GetModuleHandleA( "vstdlib.dll" );

	if( !hModule )
		return;

	RandomSeed = ( RandomSeedFn )GetProcAddress( hModule, "RandomSeed" );
	RandomFloat = ( RandomFloatFn )GetProcAddress( hModule, "RandomFloat" );
}

CAccuracy::~CAccuracy( void )
{

}

void CAccuracy::ApplyRecoilFix( CUserCmd* pCmd )
{
	auto pLocal = C_CSPlayer::GetLocalPlayer( );

	if( !pLocal )
		return;

	pCmd->viewangles -= pLocal->GetPunchAngle( ) * 2.0f;
}

void CAccuracy::ApplySpreadFix( CUserCmd* pCmd )
{
	pCmd->random_seed = 141;

	pCmd->command_number = (2076615043);

	Vector3 vForward, vRight, vUp;

	AngleVectors( pCmd->viewangles, &vForward, &vRight, &vUp );

	Vector3 vSpread;

	GetSpread( pCmd->random_seed, vSpread );

	Vector3 vDirection = vForward + vRight * -vSpread.x + vUp * -vSpread.y;

	VectorNormalize( vDirection );

	Vector3 vDest;

	VectorAngles( vDirection, vDest );

	pCmd->viewangles = vDest;
}

void CAccuracy::GetSpreadFix( int iSeed, const Vector3& viewangles, Vector3& vOut )
{
	Vector3 vForward, vRight, vUp;

	AngleVectors( viewangles, &vForward, &vRight, &vUp );

	Vector3 vSpread;

	GetSpread( iSeed, vSpread );

	Vector3 vDirection = vForward + vRight * -vSpread.x + vUp * -vSpread.y;

	VectorNormalize( vDirection );

	Vector3 vDest;

	VectorAngles( vDirection, vDest );

	vOut = viewangles - vDest;
}

void CAccuracy::GetSpread(int iSeed, Vector3& vOut)
{
	auto pLocal = C_CSPlayer::GetLocalPlayer();

	if (!pLocal)
		return;

	auto pWeapon = pLocal->GetActiveWeapon();

	if (!pWeapon)
		return;

	float flSpread = pWeapon->GetSpread();

	RandomSeed((iSeed & 255) + 1);

	float flRandomX = RandomFloat(-0.5f, 0.5f) + RandomFloat(-0.5f, 0.5f);
	float flRandomY = RandomFloat(-0.5f, 0.5f) + RandomFloat(-0.5f, 0.5f);

	vOut.x = flRandomX * flSpread;
	vOut.y = flRandomY * flSpread;
}
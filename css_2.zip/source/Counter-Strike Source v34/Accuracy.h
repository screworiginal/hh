#ifndef ACCURACY_H
#define ACCURACY_H

#pragma once

#include "SDK.h"

typedef void ( *RandomSeedFn )( unsigned int );
typedef float ( *RandomFloatFn )( float, float );

class CAccuracy
{
public:
					CAccuracy( void );
					~CAccuracy( void );

	void			ApplyRecoilFix( CUserCmd* pCmd );
	void			ApplySpreadFix( CUserCmd* pCmd );

	void			GetSpreadFix( int iSeed, const Vector3& viewangles, Vector3& vOut );

private:
	void			GetSpread( int iSeed, Vector3& vOut );

private:
	RandomSeedFn	RandomSeed;
	RandomFloatFn	RandomFloat;
};

#endif // ACCURACY_H
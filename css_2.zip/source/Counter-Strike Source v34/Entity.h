#ifndef ENTITY_H
#define ENTITY_H

#pragma once

#include "SDK.h"

class C_BaseEntity
{
public:
	// ICollideable
	const Vector3&	GetMins( void );	// 1
	const Vector3&	GetMaxs( void );	// 2

	// IClientNetworkable
	CList*			GetList( void );	// 2
	bool			IsDormant( void );	// 8
	int				GetIndex( void );	// 9

	// IClientRenderable
	const model_t*	GetModel( void );	// 8
	bool			SetupBones( Matrix3x4* pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime );	// 15

	// C_BaseEntity
	void*			GetCollideable( void );	// 3
	unsigned char	m_MoveType();

	const Vector3&	GetAbsOrigin( void );	// 9
	const Vector3&	GetAbsAngles( void );	// 10
	bool				IsDefusing();

	bool			IsPlayer( void );		// 118

	// Members
	int				GetTeamNumber( void );	// DT_BaseEntity->m_iTeamNum
};

#endif // ENTITY_H
//========= Copyright � 1996-2005, Valve Corporation, All rights reserved. ============//
//
// Purpose: A temporary file to accommodate the relocation of header into tier0
//
// $NoKeywords: $
//=============================================================================//

#include "tier0/basetypes.h"

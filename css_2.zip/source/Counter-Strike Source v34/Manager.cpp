#include "Manager.h"
#include "Main.h"

CManager::CManager( void )
{
	auto pList = Main::m_pClient->GetList( );

	if( !pList )
		return;

	while( pList )
	{
		m_pTableList.push_back( pList->m_pRecvTable );

		pList = pList->m_pNext;
	}
}

CManager::~CManager( void )
{
	
}

int CManager::Get( const std::string& szTable, const std::string& szName )
{
	auto iResult = GetProp( szTable, szName );

	if( !iResult )
		return 0;

	return iResult;
}

int CManager::GetProp( const std::string& szTable, const std::string& szName )
{
	auto pTable = GetTable( szTable );

	if( !pTable )
		return 0;

	auto iResult = GetProp( pTable, szName );

	if( !iResult )
		return 0;

	return iResult;
}

int CManager::GetProp( RecvTable* pTable, const std::string& szName )
{
	auto iExtra = 0;

	for( auto i = 0; i < pTable->m_nProps; i++ )
	{
		RecvProp* pProp = &pTable->m_pProps[i];

		if( pProp )
		{
			RecvTable* pChild = pProp->m_pDataTable;

			if( pChild && pChild->m_nProps )
			{
				auto iData = GetProp( pChild, szName );

				if( iData )
					iExtra += ( pProp->m_Offset + iData );
			}

			if( szName.compare( pProp->m_pVarName ) != 0 )
				continue;

			return ( pProp->m_Offset + iExtra );
		}
	}

	return iExtra;
}

RecvTable* CManager::GetTable( const std::string& szName )
{
	if( !m_pTableList.empty( ) )
	{
		for( auto& pTable : m_pTableList )
		{
			if( szName.compare( pTable->m_pNetTableName ) == 0 )
				return pTable;
		}
	}

	return nullptr;
}
#ifndef COLOR_H
#define COLOR_H

#pragma once

#include "SDK.h"

class Color
{
public:
	Color( void );
	Color( uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255 );
	Color( const Color& other );

	Color& operator=( const Color& other );

	int R( void ) const;
	int G( void ) const;
	int B( void ) const;
	int A( void ) const;

	static Color None( void );
	static Color White( void );
	static Color Black( void );
	static Color Red( void );
	static Color Green( void );
	static Color Blue( void );
	static Color Cyan( void );
	static Color Yellow( void );
	static Color Rainbow(void);

private:
	uint8_t r, g, b, a;
};

#endif // COLOR_H
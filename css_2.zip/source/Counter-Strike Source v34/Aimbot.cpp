#include "Aimbot.h"
#include "Main.h"
#include "Player.h"
#include "Weapon.h"
#include "Config.h"
#include "Accuracy.h"
#include "Renderer.h"

CAimbot::CAimbot( void )
{
	m_pCmd = nullptr;

	m_pLocal = nullptr;
	m_pWeapon = nullptr;

	m_iBestIndex = -1;
	m_flBestTarget = 0.0f;
}

bool IsWeaponRCS( C_WeaponCSBase* pWeapon )
{
	if( !pWeapon )
		return false;

	CSWeaponType Type = pWeapon->GetCSWpnData( ).m_WeaponType;

	return ( Type == WEAPONTYPE_MACHINEGUN ||
			 Type == WEAPONTYPE_RIFLE ||
			 Type == WEAPONTYPE_SUBMACHINEGUN );
}

void CAimbot::Execute( CUserCmd* pCmd )
{
	if( Main::m_pConfig->m_AimbotType == 0 )
		return;

	m_pCmd = pCmd;

	if( !m_pCmd )
		return;


	m_pLocal = C_CSPlayer::GetLocalPlayer( );

	if( !m_pLocal )
		return;

	m_pWeapon = m_pLocal->GetActiveWeapon( );

	if( !m_pWeapon )
		return;

	if(Main::m_pConfig->m_AimbotKeys)
	{
		if( !Main::m_pRenderer->IsKeyPressed(Main::m_pConfig->m_AimbotKeys) || m_iBestIndex == -1 )
			GetBestTarget( );
	}
	else
	{
		if( m_iBestIndex == -1 )
			GetBestTarget( );
	}

	DropTarget( );

	if( m_iBestIndex != -1 )
	{
		Vector3 vDirection = m_vEnd - m_pLocal->GetEyePosition( );

		VectorNormalize( vDirection );

		Vector3 vAim;

		VectorAngles( vDirection, vAim );

		if( Main::m_pConfig->m_AimbotRCS )
		{
			if( IsWeaponRCS( m_pWeapon ) )
			{
				if( m_pLocal->GetShotsFired( ) >= ( int )Main::m_pConfig->m_AimbotRCSDelay )
					vAim -= m_pLocal->GetPunchAngle( ) * 2.0f;
			}
			if (Main::m_pConfig->m_AimbotRCS)
			{
				auto punch = m_pLocal->GetPunchAngle();

				if (m_pLocal->GetShotsFired() >= Main::m_pConfig->m_AimbotRCSDelay)
				{
					if (Main::m_pConfig->m_AimbotRcsX)
						vAim.x -= punch.x * ((float)Main::m_pConfig->m_AimbotRcsX / 50.0f);

					if (Main::m_pConfig->m_AimbotRcsY)
						vAim.y -= punch.y * ((float)Main::m_pConfig->m_AimbotRcsY / 50.0f);
				}
			}
		}

		if( Main::m_pConfig->m_AimbotSmooth > 1 )
		{
			Vector3 vDelta( m_pCmd->viewangles - vAim );

			AngleNormalize( vDelta );

			vAim = m_pCmd->viewangles - vDelta / Main::m_pConfig->m_AimbotSmooth;
		}
		if (Main::m_pConfig->m_AimbotSmooth == 1) // Step
			ApplyStepSmooth(vAim);
		else if (Main::m_pConfig->m_AimbotSmooth == 2) // Linear
			ApplyLinearSmooth(vAim);

		vAim.z = 0.0f;

		AngleNormalize(vAim);

		vAim.z = 0.0f;

		m_pCmd->viewangles = vAim;

		if( !Main::m_pConfig->m_AimbotSilent && !Main::m_pConfig->m_AimbotPSilent )
			Main::m_pEngine->SetViewAngles( m_pCmd->viewangles );

		if( Main::m_pConfig->m_AimbotAutoShoot )
		{
			if( !m_pWeapon->GetClip1( ) )
			{
				m_pCmd->buttons |= IN_RELOAD;
				m_pCmd->buttons &= ~IN_ATTACK;
			}
			else
			{
				m_pCmd->buttons &= ~IN_RELOAD;
				m_pCmd->buttons |= IN_ATTACK;
			}
		}

		return;
	}
	
	return;
}
void CAimbot::ApplyLinearSmooth(Vector3& vAim)
{
	Vector3 vDelta = m_pCmd->viewangles - vAim;

	AngleNormalize(vDelta);

	float flFactorX = Main::m_pConfig->m_AimbotSmoothX;
	float flFactorY = Main::m_pConfig->m_AimbotSmoothY;

	if (flFactorX > 0.0f)
		vAim.x = m_pCmd->viewangles.x - vDelta.x / flFactorX;

	if (flFactorY > 0.0f)
		vAim.y = m_pCmd->viewangles.y - vDelta.y / flFactorY;
}
void CAimbot::ApplyStepSmooth(Vector3& vAim)
{
	Vector3 vDelta = vAim - m_pCmd->viewangles;

	AngleNormalize(vDelta);

	if (Main::m_pConfig->m_AimbotStepX > 0.0f)
	{
		float flFactorX = (Main::m_pConfig->m_AimbotStepX / 100.0f);

		if (vDelta.x < 0.0f)
		{
			if (flFactorX > fabs(vDelta.x))
				flFactorX = fabs(vDelta.x);

			vAim.x = m_pCmd->viewangles.x - flFactorX;
		}
		else
		{
			if (flFactorX > vDelta.x)
				flFactorX = vDelta.x;

			vAim.x = m_pCmd->viewangles.x + flFactorX;
		}
	}
	if (Main::m_pConfig->m_AimbotStepY > 0.0f)
	{
		float flFactorY = (Main::m_pConfig->m_AimbotStepY / 100.0f);

		if (vDelta.y < 0.0f)
		{
			if (flFactorY > fabs(vDelta.y))
				flFactorY = fabs(vDelta.y);

			vAim.y = m_pCmd->viewangles.y - flFactorY;
		}
		else
		{
			if (flFactorY > vDelta.y)
				flFactorY = vDelta.y;

			vAim.y = m_pCmd->viewangles.y + flFactorY;
		}
	}
}


void UTIL_ClipTraceToPlayers( const Vector3& vecAbsStart, const Vector3& vecAbsEnd, unsigned int mask, ITraceFilter* filter, trace_t* tr )
{
	typedef void ( *UTIL_ClipTraceToPlayersFn )( const Vector3&, const Vector3&, unsigned int, ITraceFilter*, trace_t* );

	static auto UTIL_ClipTraceToPlayers = ( UTIL_ClipTraceToPlayersFn )Main::PatternScan( "client.dll", "81 EC ?? ?? ?? ?? 8B 84 24 ?? ?? ?? ?? 8B 48 2C" );

	if( !UTIL_ClipTraceToPlayers )
		return;

	UTIL_ClipTraceToPlayers( vecAbsStart, vecAbsEnd, mask, filter, tr );
}

bool CAimbot::CanHit( int random_seed, Vector3 viewangles )
{
	m_pLocal = C_CSPlayer::GetLocalPlayer( );

	if( !m_pLocal )
		return false;

	m_pWeapon = m_pLocal->GetActiveWeapon( );

	if( !m_pWeapon )
		return false;

	viewangles += m_pLocal->GetPunchAngle( ) * 2.0f;

	if( Main::m_pConfig->m_TriggerbotPerfect == 1 ) //Perfct
	{
		Vector3 vSpread;

		Main::m_pAccuracy->GetSpreadFix( random_seed, viewangles, vSpread );

		viewangles += vSpread;
	}


	Vector3 vEnd;

	AngleVectors( viewangles, &vEnd );

	Vector3 vStart = m_pLocal->GetEyePosition( );

	vEnd = vEnd * m_pWeapon->GetCSWpnData( ).m_flRange + vStart;

	Vector3 vDir = vEnd - vStart;

	VectorNormalize( vDir );

	trace_t tr;
	Ray_t ray;

	CTraceFilterSimple trace( m_pLocal );

	ray.Init( vStart, vEnd );

	Main::m_pEngineTrace->TraceRay( ray, 0x4600400B, &trace, &tr );

	const float rayExtension = 40.0f;

	UTIL_ClipTraceToPlayers( vStart, vEnd + vDir * rayExtension, 0x4600400B, &trace, &tr );

	auto pPlayer = ( C_CSPlayer* )tr.m_pEnt;

	if( !pPlayer )
		return false;

	if( !pPlayer->IsPlayer( ) )
		return false;

	if( pPlayer->IsDead( ) )
		return false;

	if( pPlayer->GetTeamNumber( ) == m_pLocal->GetTeamNumber( ) )
		return false;

	if( tr.hitbox == ( int )Main::m_pConfig->m_TriggerbotHitbox )
		return true;

	return false;
}

void CAimbot::DropTarget( )
{
	if(Main::m_pConfig->m_AimbotKeys)
	{
		if( !Valid( m_iBestIndex ) || !Main::m_pRenderer->IsKeyPressed(Main::m_pConfig->m_AimbotKeys))
			m_iBestIndex = -1; 
	}
	else
	{
		if( !Valid( m_iBestIndex ) )
			m_iBestIndex = -1;
	}
}

void CAimbot::GetBestTarget( )
{
	m_flBestTarget = Main::m_pConfig->m_AimbotFOV;

	auto nSize = Main::m_pEngine->GetMaxClients( );

	for( auto i = 1; i <= nSize; i++ )
	{
		if( Valid( i ) )
		{
			float flFOV = GetFOV( m_pCmd->viewangles, m_pLocal->GetEyePosition( ), m_vEnd );

			if( flFOV < m_flBestTarget )
			{
				m_flBestTarget = flFOV;
				m_iBestIndex = i;
			}
		}
	}
}

void GetBulletTypeParameters( int iBulletType, float& fPenetrationPower, float& flPenetrationDistance )
{
	typedef void ( __stdcall* GetBulletTypeParametersFn )( int, float&, float& );
	static auto GetBulletTypeParameters = ( GetBulletTypeParametersFn )Main::PatternScan( "client.dll", "56 8B 74 24 08 68 ?? ?? ?? ?? 56 E8 ?? ?? ?? ?? 83 C4 08 84 C0" );

	if( !GetBulletTypeParameters )
		return;

	GetBulletTypeParameters( iBulletType, fPenetrationPower, flPenetrationDistance );
}

static void GetMaterialParameters( int iMaterial, float& flPenetrationModifier, float& flDamageModifier )
{
	switch (iMaterial)
	{
	case CHAR_TEX_METAL:
		flPenetrationModifier = 0.5;
		flDamageModifier = 0.3;
		break;
	case CHAR_TEX_DIRT:
		flPenetrationModifier = 0.5;
		flDamageModifier = 0.3;
		break;
	case CHAR_TEX_CONCRETE:
		flPenetrationModifier = 0.4;
		flDamageModifier = 0.25;
		break;
	case CHAR_TEX_GRATE:
		flPenetrationModifier = 1.0;
		flDamageModifier = 0.99;
		break;
	case CHAR_TEX_VENT:
		flPenetrationModifier = 0.5;
		flDamageModifier = 0.45;
		break;
	case CHAR_TEX_TILE:
		flPenetrationModifier = 0.65;
		flDamageModifier = 0.3;
		break;
	case CHAR_TEX_COMPUTER:
		flPenetrationModifier = 0.4;
		flDamageModifier = 0.45;
		break;
	case CHAR_TEX_WOOD:
		flPenetrationModifier = 1.0;
		flDamageModifier = 0.6;
		break;
	default:
		flPenetrationModifier = 1.0;
		flDamageModifier = 0.5;
		break;
	}
}

static bool TraceToExit( Vector3& start, Vector3& dir, Vector3& end, float flStepSize, float flMaxDistance )
{
	float flDistance = 0;
	Vector3 last = start;

	while( flDistance <= flMaxDistance )
	{
		flDistance += flStepSize;

		end = start + flDistance * dir;

		if( ( Main::m_pEngineTrace->GetPointContents( end ) & 0x200400B ) == 0 )
			return true;
	}

	return false;
}

int GetPlayerModifiedDamage( float flDamage, int iArmorValue, float flArmorRatio, bool bIsHeadshot, bool bIsFriendly, bool bHasHelmet )
{
	if( bIsFriendly )
		flDamage *= .35f;

	flArmorRatio *= .5f;

	if( iArmorValue > 0 && !bIsHeadshot || bIsHeadshot && bHasHelmet )
	{
		float flNew = flDamage * flArmorRatio;
		float flArmor = ( flDamage - flNew ) * .5f;

		if( flArmor <= iArmorValue )
		{
			flArmor = floor( flArmor );
		}
		else
		{
			flNew = flDamage + ( iArmorValue * -2.f );
			flArmor = iArmorValue;
		}

		flDamage = floor( flNew );
	}
	else
	{
		flDamage = floor( flDamage );
	}

	return ( int )flDamage;
}

float GetHitgroupModifiedDamage( float flDamage, int iHitgroup )
{
	static float flHitgroupModifiers[] = { 1.f, 4.f, 1.f, 1.25f, 1.f, 1.f, .75f, .75f };
	return flDamage * flHitgroupModifiers[iHitgroup];
}

bool CAimbot::CanPenetrate( const Vector3& vStart, const Vector3& vEnd, int& iHitbox, int& iHitgroup, C_CSPlayer** ppPlayerHit, int iMinDamage )
{
	Ray_t ray;

	float flDistance = m_pWeapon->GetCSWpnData( ).m_flRange;
	int	iPenetration = m_pWeapon->GetCSWpnData( ).m_iPenetration;
	int iBulletType = m_pWeapon->GetPrimaryAmmoType( );
	int	iDamage = m_pWeapon->GetCSWpnData( ).m_iDamage;
	float flRangeModifier = m_pWeapon->GetCSWpnData( ).m_flRangeModifier;

	float fCurrentDamage = ( int )iDamage;
	float flCurrentDistance = 0.0;

	float flPenetrationPower = 0;
	float flPenetrationDistance = 0;
	float flDamageModifier = 0.5;
	float flPenetrationModifier = 1.f;

	GetBulletTypeParameters( iBulletType, flPenetrationPower, flPenetrationDistance );

	Vector3 vecSrc = vStart;

	Vector3 vecDir = vEnd - vStart;
	VectorNormalize( vecDir );

	C_CSPlayer* lastPlayerHit = nullptr;

	int iModifiedDamage = 0;

	while( fCurrentDamage > 0 )
	{
		Vector3 vecEnd = vecSrc + vecDir * flDistance;

		trace_t tr;

		CTraceFilterSkipTwoEntities filter( m_pLocal, lastPlayerHit );

		ray.Init( vecSrc, vecEnd );
		Main::m_pEngineTrace->TraceRay( ray, 0x4600400B, &filter, &tr );

		const float rayExtension = 40.0f;
		UTIL_ClipTraceToPlayers( vecSrc, vecEnd + vecDir * rayExtension, 0x4600400B, &filter, &tr );

		lastPlayerHit = ToCSPlayer( tr.m_pEnt );

		if( tr.fraction == 1.0f )
			break;

		surfacedata_t* pSurfaceData = Main::m_pPhysics->GetSurfaceData( tr.surface.surfaceProps );
		int iEnterMaterial = pSurfaceData->game.material;

		GetMaterialParameters( iEnterMaterial, flPenetrationModifier, flDamageModifier );

		bool hitGrate = tr.contents & 0x8;

		if( hitGrate )
		{
			flPenetrationModifier = 1.0f;
			flDamageModifier = 0.99f;
		}

		flCurrentDistance += tr.fraction * flDistance;
		fCurrentDamage *= pow( flRangeModifier, ( flCurrentDistance / 500 ) );

		if( flCurrentDistance > flPenetrationDistance && iPenetration > 0 )
			iPenetration = 0;

		if( lastPlayerHit )
		{
			static ConVar* mp_friendlyfire = Main::m_pCvar->FindVar( "mp_friendlyfire" );

			if( mp_friendlyfire->GetBool( ) && lastPlayerHit->GetTeamNumber( ) == m_pLocal->GetTeamNumber( ) || lastPlayerHit->GetTeamNumber( ) != m_pLocal->GetTeamNumber( ) )
			{
				if( iHitbox == -1 )
					iHitbox = tr.hitbox;

				if( iHitgroup == -1 )
					iHitgroup = tr.hitgroup;

				iModifiedDamage += GetPlayerModifiedDamage( GetHitgroupModifiedDamage( fCurrentDamage, tr.hitgroup ), lastPlayerHit->GetArmor( ), m_pWeapon->GetCSWpnData( ).m_flArmorRatio, tr.hitgroup == 1, lastPlayerHit->GetTeamNumber( ) == m_pLocal->GetTeamNumber( ), lastPlayerHit->HasHelmet( ) );

				if( ppPlayerHit && !*ppPlayerHit )
					*ppPlayerHit = lastPlayerHit;
			}
		}

		if( iPenetration == 0 && !hitGrate )
			break;

		if( iPenetration < 0 )
			break;

		Vector3 penetrationEnd;

		if( !TraceToExit( tr.endpos, vecDir, penetrationEnd, 24, 128 ) )
			break;

		trace_t exitTr;

		ray.Init( penetrationEnd, tr.endpos );
		Main::m_pEngineTrace->TraceRay( ray, 0x4600400B, 0, &exitTr );

		if( exitTr.m_pEnt != tr.m_pEnt && exitTr.m_pEnt != NULL )
		{
			CTraceFilterSimple filter( exitTr.m_pEnt );

			ray.Init( penetrationEnd, tr.endpos );
			Main::m_pEngineTrace->TraceRay( ray, 0x4600400B, &filter, &exitTr );
		}

		pSurfaceData = Main::m_pPhysics->GetSurfaceData( exitTr.surface.surfaceProps );
		int iExitMaterial = pSurfaceData->game.material;

		hitGrate = hitGrate && ( exitTr.contents & 0x8 );

		if( iEnterMaterial == iExitMaterial )
		{
			if( iExitMaterial == CHAR_TEX_WOOD ||
				iExitMaterial == CHAR_TEX_METAL )
			{
				flPenetrationModifier *= 2;
			}
		}

		float flTraceDistance = exitTr.endpos.DistTo( tr.endpos );

		if( flTraceDistance > ( flPenetrationPower * flPenetrationModifier ) )
			break;

		flPenetrationPower -= flTraceDistance / flPenetrationModifier;
		flCurrentDistance += flTraceDistance;
		vecSrc = exitTr.endpos;
		flDistance = ( flDistance - flCurrentDistance ) * 0.5;

		fCurrentDamage *= flDamageModifier;

		iPenetration--;
	}

	if( iModifiedDamage == 0 )
		iModifiedDamage = -1;

	if( iModifiedDamage >= iMinDamage )
		return true;

	return false;
}

bool CAimbot::Valid( int index )
{
	auto pEntity = Main::m_pEntList->GetClientEntity( index );

	if( !pEntity )
		return false;

	C_CSPlayer* pPlayer = ToCSPlayer( pEntity );

	if( !pPlayer )
		return false;

	if( pPlayer->IsDormant( ) )
		return false;

	if( pPlayer->IsDead( ) )
		return false;

	if( pPlayer->GetHealth( ) > 500 )
		return false;

	if( pPlayer->GetTeamNumber( ) == m_pLocal->GetTeamNumber( ) )
		return false;


	else if( Main::m_pConfig->m_AimbotType )
	{
		if( !pPlayer->GetHitboxPosition( Main::m_pConfig->m_AimbotHitbox, m_vEnd ) )
			return false;
	}


	if( Main::m_pConfig->m_AimbotAutoWall )
	{
		int iHitbox = -1;
		int iHitgroup = -1;

		C_CSPlayer* pPlayerHit = nullptr;

		if( !CanPenetrate( m_pLocal->GetEyePosition( ), m_vEnd, iHitbox, iHitgroup, &pPlayerHit, ( int )Main::m_pConfig->m_AimbotAutoWall ) )
			return false;
	}
	else
	{
		if( !Main::Visible( m_vEnd, pEntity ) )
			return false;
	}

	return true;
}

void CAimbot::MakeVector( const Vector3& vIn, Vector3& vOut )
{
	float pitch = Deg2Rad( vIn.x );
	float yaw	= Deg2Rad( vIn.y );
	float temp	= cos( pitch );

	vOut.x = -temp * -cos( yaw );
	vOut.y = sin( yaw ) * temp;
	vOut.z = -sin( pitch );
}

float CAimbot::GetFOV( const Vector3& viewangles, const Vector3& vStart, const Vector3& vEnd )
{
	Vector3 vAng, vAim;

	Vector3 vDir = vEnd - vStart;

	VectorNormalize( vDir );

	VectorAngles( vDir, vAng );

	MakeVector( viewangles, vAim );
	MakeVector( vAng, vAng );

	return Rad2Deg( acos( vAim.Dot( vAng ) ) / vAim.LengthSqr( ) );
}
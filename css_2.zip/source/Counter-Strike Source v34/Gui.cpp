#include "Gui.h"
#include "Main.h"
#include "Config.h"
#include "Renderer.h"
#include "Weapon.h"
#include "Entity.h"
#include "public\tier0\basetypes.h"



CMenu* g_pGameGui = new CMenu();

using namespace Main;

Color MenuTop = Color(30, 160, 238, 235);
Color MenuBG = Color(36, 37, 40, 235);
Color MenuBG2 = Color(36, 37, 40, 255);
Color Font = Color(220, 236, 194);
Color FontW = Color::White();
Color Selected = Color(37, 165, 235, 220);
int Ragebot[2] = { 5,30 };
int Legitbot[2] = { 510,30 };
int Visuals[2] = { 1015,30 };
int Render2[2] = { 5,30 };
int Misc[2] = { 5,433 };
int Configs[2] = { 510,433 };
int CustomAA[2] = { 1015,433 };
int Removals[2] = { 6,433 };


ScreenSize_t sScreenSize;
ScreenSize_t sScreenSize2;

tagPOINT Mouse;
int SavedX, SavedY;
bool bCfg = true;
bool bOnze = true;
bool bSave = false;
bool bSaveMonitorPos = false;
bool bSavePos = true;
bool bLock = false;
bool bClick = true;
bool bLoad = true;
bool bMouseOnce = true;
int Selection = 1, iSel = 0;
bool bIsRage = false;

//char* Keys[255] = { "Press Any Key", "L Mouse", "R Mouse", "Cancel", "M Mouse", "", "", "", "Backspace", "Tab", "", "", "Clear", "Return", "", "", "Shift", "Ctrl", "Alt", "Pause", "Caps Lock", "", "", "", "", "", "", "Escape", "", "", "", "", "Spacebar", "Page up", "Page down", "End", "Home", "L Arrow", "Up Arrow", "R Arrow", "D Arrow", "Select", "Print", "Execute", "P.Screen", "Insert", "Delete", "Help", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "", "", "", "", "", "", "", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "L.Menu", "R.Menu", "App", "", "Sleep", "Num 0", "Num 1", "Num 2", "Num 3", "Num 4", "Num 5", "Num 6", "Num 7", "Num 8", "Num 9", "Multiply", "Add", "Separator", "Subtract", "Decimal", "Divide", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "", "", "", "", "", "", "", "", "NumLock", "ScrLock", "Equals", "", "", "", "", "", "", "", "", "", "", "", "", "", "LShift", "RShift", "LCtrl", "RCtrl", "LMenu", "RMenu" };
char* AimSelect[3] = { "Distance", "Field of View", "Next Shot" };
//char* Removals[3] = { "Off", "Only Aimbot", "Always" };
char* AntiAimX[4] = { "SMAC/KAC Safe", "Normal", "Configurable", "Static" };
char* AntiAimY[6] = { "Normal", "Jitter", "Configurable", "Spinhack", "Fake Sideways", "Fake Static" };
char* Keys[11] = { "None", "LMouse", "RMouse", "Mouse 4", "Mouse 5", "Shift", "Control", "Alt", "Q", "F", "E" };
char* TrigMode[3] = { "Normal", "No Spread", "Seed" };
char* ESPStyle[3] = { "Off", "Box", "BoxOut" };
char* ESPHealth[3] = { "Off", "Text", "Bar" };
char* ESPArmor[3] = { "Off", "Text", "Bar" };

char* AimMethod[3] = { "Hitbox", "Bone", "Hack vs Hack" };
char* Strafe[3] = { "Off", "Assist", "Full" };
char* ChamsStyle[3] = { "Off", "Flat", "Shadow" };
char* Triggermode[3] = { "Off", "Perfect", "Seed" };

char* szKeyNames[] = {
	"",
	"Mouse 1",
	"Mouse 2",
	"",
	"Middle Mouse",
	"Mouse 4",
	"Mouse 5",
	"",
	"Backspace",
	"Tab",
	"",
	"",
	"",
	"Enter",
	"",
	"",
	"Shift",
	"Control",
	"Alt",
	"Pause",
	"Caps",
	"",
	"",
	"",
	"",
	"",
	"",
	"Escape",
	"",
	"",
	"",
	"",
	"Space",
	"Page Up",
	"Page Down",
	"End",
	"Home",
	"Left",
	"Up",
	"Right",
	"Down",
	"",
	"",
	"",
	"Print",
	"Insert",
	"Delete",
	"",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"",
	"",
	"",
	"",
	"",
	"",
	"",
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L",
	"M",
	"N",
	"O",
	"P",
	"Q",
	"R",
	"S",
	"T",
	"U",
	"V",
	"W",
	"X",
	"Y",
	"Z",
	"",
	"",
	"",
	"",
	"",
	"Numpad 0",
	"Numpad 1",
	"Numpad 2",
	"Numpad 3",
	"Numpad 4",
	"Numpad 5",
	"Numpad 6",
	"Numpad 7",
	"Numpad 8",
	"Numpad 9",
	"Multiply",
	"Add",
	"",
	"Subtract",
	"Decimal",
	"Divide"
};
char* SpreadList[] = { "Disabled", "Pitch / Yaw", "Seed Tick", "Both" };

char* SmoothList[] =
{
	"Off",
	"Step",
	"Linear",
};

char* TargetList[] =
{
	"Everyone",
	"Enemy",
	"Friendly",
};

char* ModeList[] =
{
	"Off",
	"Auto",
	"On Press",
};

char* SpotList[] =
{
	"Pelvis",
	"Left Thigh",
	"Left Calf",
	"Left Foot",
	"Left Toe",
	"Right Thigh",
	"Right Calf",
	"Right Foot",
	"Right Toe",
	"Spine 1",
	"Spine 2",
	"Neck",
	"Head",
	"Left Upper Arm",
	"Left Forearm",
	"Left Hand",
	"Right Upper Arm",
	"Right Forearm",
	"Right Hand",
};

enum Tabs
{
	tab0,
	tab1,
	tab2,
	tab3,
	tab4,
	tab5,
	tab6,
	tab7,
	tab8,
	tab9
};

struct OpenTab
{
	Tabs ActiveTab;
} openTab;

struct sComboBox
{
	bool Open, Active;
	int iSelect;
	char* Name;
} cComboBox[21];

void ESPBox(int x, int y, int x1, int y1, int r, int g, int b, int a)
{
	m_pRenderer->Border(x, y, x1, y1, 1, r, g, b, a);
	m_pRenderer->Border(x - 1, y - 1, x1 + 2, y1 + 2, 1, 0, 0, 0, 255);
	m_pRenderer->Border(x + 1, y + 1, x1 - 2, y1 - 2, 1, 0, 0, 0, 255);
}

void DrawMouse(int x, int y)
{
	/*m_pRenderer->FillRGBA(x, y, 1, 1, 0,0,0,255);
	m_pRenderer->FillRGBA(x, (y + 1), 2, 1, 0,0,0,255);

	for (int i = 0; i <= 8; ++i)
	{
	m_pRenderer->FillRGBA(x, ((y + 1) + i), 1, 1, 0,0,0,255);
	m_pRenderer->FillRGBA((x + 1), ((y + 1) + i), i, 1, 0, 180, 240,230);
	m_pRenderer->FillRGBA(((x + 1) + i), ((y + 1) + i), 1, 1, 0,0,0,255);
	}

	m_pRenderer->FillRGBA(x, (y + 10), 1, 1, 0,0,0,255);
	m_pRenderer->FillRGBA((x + 1), (y + 10), 3, 1, 0, 180, 240,230);
	m_pRenderer->FillRGBA((x + 4), (y + 10), 7, 1, 0,0,0,255);
	m_pRenderer->FillRGBA(x, (y + 11), 1, 1, 0,0,0,255);
	m_pRenderer->FillRGBA((x + 1), (y + 11), 2, 1, 0, 180, 240,230);
	m_pRenderer->FillRGBA((x + 3), (y + 11), 1, 1, 0,0,0,255);
	m_pRenderer->FillRGBA(x, (y + 12), 1, 1, 0,0,0,255);
	m_pRenderer->FillRGBA((x + 1), (y + 12), 1, 1, 0, 180, 240,230);
	m_pRenderer->FillRGBA((x + 2), (y + 12), 1, 1, 0,0,0,255);
	m_pRenderer->FillRGBA(x, (y + 13), 2, 1, 0,0,0,255);
	m_pRenderer->FillRGBA(x, (y + 14), 1, 1, 0,0,0,255);*/

	/*m_pRenderer->FillRGBA(x, y, 1, 17, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x, y + 16, 2, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 2, y + 15, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 3, y + 14, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 4, y + 13, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 5, y + 14, 1, 2, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 6, y + 16, 1, 2, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 7, y + 18, 2, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 8, y + 14, 1, 2, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 9, y + 16, 1, 2, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 7, y + 12, 1, 2, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 7, y + 12, 5, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 11, y + 11, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 10, y + 10, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 9, y + 9, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 8, y + 8, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 7, y + 7, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 6, y + 6, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 5, y + 5, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 4, y + 4, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 3, y + 3, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 2, y + 2, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 1, y + 1, 1, 1, 0, 0, 0, 255);
	m_pRenderer->FillRGBA(x + 1, y + 2, 1, 14, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 2, y + 3, 1, 12, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 3, y + 4, 1, 10, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 4, y + 5, 1, 8, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 5, y + 6, 1, 8, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 6, y + 7, 1, 9, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 7, y + 8, 1, 4, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 8, y + 9, 1, 3, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 9, y + 10, 1, 2, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 10, y + 11, 1, 1, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 7, y + 14, 1, 4, 255, 255, 255, 255);
	m_pRenderer->FillRGBA(x + 8, y + 16, 1, 2, 255, 255, 255, 255);*/
}

bool cMouse::IsInBox(int x, int y, int w, int h)
{
	if (m_pConfig->iMouseX >= x &&
		m_pConfig->iMouseX <= x + w &&
		m_pConfig->iMouseY >= y &&
		m_pConfig->iMouseY <= y + h)
		return true;
	else
		return false;
}

void cMouse::ClickHandler()
{
	if ((GetAsyncKeyState(VK_LBUTTON)))
	{
		bMouse1pressed = true;
	}
	else if (!(GetAsyncKeyState(VK_LBUTTON)))
	{
		if (bMouse1pressed)
			bMouse1released = true;
		else
		{
			bMouse1released = false;
		}
		bMouse1pressed = false;
	}

	if ((GetAsyncKeyState(VK_RBUTTON)))
	{
		bMouse2pressed = true;
	}
	else if (!(GetAsyncKeyState(VK_RBUTTON)))
	{
		if (bMouse2pressed)
			bMouse2released = true;
		else
		{
			bMouse2released = false;
		}
		bMouse2pressed = false;
	}
}

bool cMouse::LeftClick(int x, int y, int w, int h)
{
	if (IsInBox(x, y, w, h) && GetAsyncKeyState(VK_LBUTTON))
		return true;
	else
		return false;
}

void CfgSelectButton(int x, int y)
{
	if (m_pMouse->IsInBox(x, y, 45, 15))
	{
		m_pRenderer->FillRGBA(x, y, 45, 15, 0, 220, 220, 255);
		if (m_pMouse->bMouse1released)
		{
			bIsRage = !bIsRage;
			m_pConfig->Load();
		}
	}
	else
	{
		m_pRenderer->FillRGBA(x, y, 45, 15, 0, 180, 220, 255);
	}

	if (bIsRage)
	{
		m_pRenderer->DrawText(x + 22, y - 1, 0, Color::White(), "Rage");
	}
	else
	{
		m_pRenderer->DrawText(x + 22, y - 1, 0, Color::White(), "Legit");
	}
}

void SaveButton(int x, int y)
{
	if (bSave)
	{
		m_pConfig->Save();
		bSave = false;
	}
	if (m_pMouse->IsInBox(x, y, 45, 15))
	{
		m_pRenderer->FillRGBA(x, y, 45, 15, 0, 220, 220, 255);
		m_pRenderer->DrawText(x + 22, y - 1, 0, Color::White(), "Save");
		if (m_pMouse->bMouse1released)
			bSave = true;
	}
	else
	{
		m_pRenderer->FillRGBA(x, y, 45, 15, 0, 180, 220, 255);
		m_pRenderer->DrawText(x + 22, y - 1, 0, Color::White(), "Save");
	}
}

void DrawInfo(char* Text)
{
	m_pRenderer->DrawText(m_pConfig->iMenuX + 165, m_pConfig->iMenuY + 445, 0, Color::White(), Text);
}

void CMenu::DrawWindow(int x, int y, int w, int h, char* cName)
{
	m_pRenderer->FillRGBA(x, y, w, h, 50, 50, 50, 220);//Background
	m_pRenderer->Border(x, y, w, h, 6, 78, 186, 242, 255);//Border
	m_pRenderer->FillRGBA(x, y, w, 25, 78, 186, 242, 255);//Topbar
	m_pRenderer->DrawText(x + 6, y + 6, 0, Color::White(), cName);//Name
	m_pRenderer->Border(x, y, w + 5, h + 5, 1, 0, 0, 0, 255);//Black 1px Outline
	m_pRenderer->Border(x + 5, y + 25, w - 5, h - 25, 1, 0, 0, 0, 255);//Black 1px Inline
}

void CMenu::DrawGroupBox(int x, int y, int w, int h, char* Name)
{
	m_pRenderer->FillRGBA(x, y, w, h, 60, 60, 60, 255);//Background
	m_pRenderer->FillRGBA(x, y, w, 20, 78, 186, 242, 255);//Topbar
	m_pRenderer->DrawText(x + 3, y + 4, 0, Color::White(), Name);
}

void CMenu::DrawComboBox(int x, int y, char* Name, int &Selection, int num, int max, char** structs, char* Description)
{
	cComboBox[num].Name = structs[Selection];
	m_pRenderer->FillRGBA(x + 2, y - 3, 100, 2, 50, 56, 70, 255);//Top
	m_pRenderer->FillRGBA(x + 2, y - 3, 2, 22, 50, 56, 70, 255);//Left
	m_pRenderer->FillRGBA(x + 100, y - 3, 2, 22, 50, 56, 70, 255);//Right
	m_pRenderer->FillRGBA(x + 4, y - 1, 96, 19, 50, 56, 70, 255);//Back 1
	if (cComboBox[num].Active)
	{
		cComboBox[num].iSelect = Selection;
		if (m_pMouse->IsInBox(x + 6, y + 1, 93, 23) && m_pMouse->bMouse1released && bClick)
		{
			cComboBox[num].Open = true;
			cComboBox[num].Active = false;
		}
		m_pRenderer->FillRGBA(x + 2, y + 17, 100, 2, 50, 56, 70, 255);//Bottom
		m_pRenderer->DrawText(x + 8, y + 1, 0, Color::White(), cComboBox[num].Name);
		if (m_pMouse->IsInBox(x + 2, y - 3, 100, 22) && !bLock)
		{
			DrawInfo(Description);
		}
	}
	else
	{
		if (cComboBox[num].Open)
		{
			bLock = true;
			DrawInfo(Description);
			for (int i = 0; i < max; i++)
			{
				m_pRenderer->FillRGBA(x + 2, y + (i * 20) - 1, 100, 24, 50, 56, 70, 255);//Back 1
				m_pRenderer->FillRGBA(x + 2, y - 1 + (i * 20), 2, 24, 50, 56, 70, 255);//Left * count
				m_pRenderer->FillRGBA(x + 100, y - 1 + (i * 20), 2, 24, 50, 56, 70, 255);//Right * count
				if (m_pMouse->IsInBox(x + 6, y + 1 + (i * 20), 93, 20))
				{
					m_pRenderer->GardientRect2(x + 6, y + 1 + (i * 20), 93, 20, Color(37, 165, 235, 255), Color(37, 165, 235, 255), 45);//highlight selection
					if (m_pMouse->bMouse1released)
					{
						cComboBox[num].iSelect = i;
						cComboBox[num].Name = structs[cComboBox[num].iSelect];
						Selection = cComboBox[num].iSelect;
						cComboBox[num].Open = false;
						cComboBox[num].Active = true;
						bLock = false;
					}
				}
				m_pRenderer->DrawText(x + 8, y + 3 + (i * 20), 0, Color::White(), structs[i]);//List struct
			}
			m_pRenderer->FillRGBA(x + 2, y + 3 + (max * 20), 100, 2, 50, 56, 70, 255);//Bottom
		}
	}

	m_pRenderer->DrawText(x + 105, y, 0, Color::White(), Name);
}

void CMenu::CloseAllComboBoxes()
{
	for (int n = 0; n <= 21; n++)
	{
		cComboBox[n].Open = false;
		cComboBox[n].Active = true;
	}
	bLock = false;
}

void CMenu::DrawCheckBox(int x, int y, const char* szString, bool &toggle, char* Description)
{
	//m_pRenderer->FillRGBA(x + 2, y - 3, 14, 14, 0,0,0,255);
	m_pRenderer->Border(x + 2, y - 3, 16, 16, 1, 103, 107, 115, 255);
	if (m_pMouse->IsInBox(x + 2, y - 3, 17, 17))
	{
		//DrawInfo(Description);
	}
	if (m_pMouse->IsInBox(x + 4, y - 1, 13, 13) && m_pMouse->bMouse1released)
	{
		toggle = !toggle;
	}
	if (toggle)
	{
		m_pRenderer->FillRGBA(x + 4, y - 1, 13, 13, 37, 165, 235, 255);
		m_pRenderer->Border(x + 2, y - 3, 16, 16, 1, 33, 37, 46, 255);
	}
	m_pRenderer->DrawText(x + 25, y - 2, 0, FontW, szString);
}

void CMenu::DrawCloseButton(int x, int y)
{
	if (m_pMouse->IsInBox(x, y, 45, 15))
	{
		m_pRenderer->FillRGBA(x, y, 45, 15, 255, 0, 0, 255);
		if (m_pMouse->bMouse1released)
			m_pConfig->bShowGUI = false;
	}
	else
	{
		m_pRenderer->FillRGBA(x, y, 45, 15, 220, 0, 0, 255);
	}
	m_pRenderer->DrawText(x + 19, y + 1, 0, Color::White(), "X");
}

void CMenu::Slider(int x, int y, bool bInt, float &iInput, float iMin, float iMax, char* Name, char* Description)
{
	float sliderpos, barpos;

	if (m_pMouse->IsInBox(x, y + 3, 200, 22))
	{
		//DrawInfo(Description);
	}

	if (m_pMouse->IsInBox(x, y + 3, 200, 19) && m_pMouse->bMouse1pressed)
	{
		sliderpos = (m_pConfig->iMouseX - x);
	}
	else
	{
		sliderpos = (((iInput * 100) * 2) / iMax);
	}

	iInput = (iMax * (sliderpos / 2) / 100);
	barpos = (sliderpos / 200 * 100) * 2;

	if (barpos > 200)
		barpos = 200;

	if (bInt)
	{
		double integral;
		float fraction = (float)modf(iInput, &integral);
		if (fraction >= 0.5)
			iInput += 1;
		iInput = (int)integral;
	}

	iInput = clamp(iInput, iMin, iMax);

	m_pRenderer->GardientRect(x, y + 5, 200, 22, Color(31, 31, 31, 255), Color(31, 31, 31, 255), 45);

	m_pRenderer->GardientRect2(x + 1, y + 6, barpos, 19, Selected, Color(Selected.R(), Selected.G(), Selected.B(), 255), 45);

	m_pRenderer->FillRGBA(x + barpos, y + 6, 9, 19, 255, 255, 255, 255);

	m_pRenderer->DrawText(x + 100, y + 8, NULL, Color::White(), "%.0f", iInput);
	m_pRenderer->DrawText(x + 208, y + 8, NULL, Color::White(), "%s", Name, iInput);
}

void CMenu::DrawTabs(const char* Name, int tab, int x, int y)
{
	m_pRenderer->FillRGBA(x, y, 165, 35, 60, 60, 60, 255);

	if (m_pMouse->IsInBox(x, y, 165, 35))
	{
		m_pRenderer->FillRGBA(x, y, 165, 35, 120, 120, 120, 255);
		if (m_pMouse->bMouse1released)
		{
			CloseAllComboBoxes();

			if (tab == 1)
				openTab.ActiveTab = tab1;
			else if (tab == 2)
				openTab.ActiveTab = tab2;
			else if (tab == 3)
				openTab.ActiveTab = tab3;
			else if (tab == 4)
				openTab.ActiveTab = tab4;
			else if (tab == 5)
				openTab.ActiveTab = tab5;
			else if (tab == 6)
				openTab.ActiveTab = tab6;
			else if (tab == 7)
				openTab.ActiveTab = tab7;
			else if (tab == 8)
				openTab.ActiveTab = tab8;
			else if (tab == 9)
				openTab.ActiveTab = tab9;
		}
	}

	m_pRenderer->DrawText(x + 35, y + 14, 0, Color::White(), Name);
}

/////////////////////////////////////////////////////

void CMenu::RenderGroupBox(int x, int y, int w, int h, std::string strText)
{
	int iTextSize[2] = { 0 };
	m_pRenderer->DrawText(x + 20, y - (iTextSize[1] / 2), NULL, Color::White(), strText.c_str());

	m_pRenderer->DrawLine(x, y, x + 16, y, MenuTop);
	m_pRenderer->DrawLine(x, y, x, y + h, MenuTop);
	m_pRenderer->DrawLine(x, y + h, x + w, y + h, MenuTop);
	m_pRenderer->DrawLine(x + w, y + h, x + w, y, MenuTop);
	m_pRenderer->DrawLine(x + w, y, x + 22 + iTextSize[0], y, MenuTop);
}

int CMenu::WhichKeyIsPressed()
{
	for (int i = 1; i < 255; ++i)
	{
		if (GetAsyncKeyState(i) & 0x8000)
			return i;
	}
}

void CMenu::RenderButton(int x, int y, std::string strText, int iIndex, int& iClicked, bool untrusted)
{
	int m_iWidth = 128;
	int m_iHeight = 26;
	auto bHover = m_pMouse->IsInBox(x, y, m_iWidth, m_iHeight);

	if (bHover && m_pMouse->bMouse1released)
		iClicked = iIndex;
	//skeet
	//gVars::dxRenderer->rect(Color(0, 0, 0).code(), real.x, real.y, size.x, size.y);
	//gVars::dxRenderer->rect(Color(48, 48, 48, 30).code(), real.x + 1, real.y + 1, size.x - 2, size.y - 2);

	m_pRenderer->RectOutlined2(x, y, m_iWidth, m_iHeight, 1, Color(0, 0, 0, 255));
	if (bHover)
		m_pRenderer->GardientRect2(x, y, m_iWidth, m_iHeight, Color(31, 31, 31, 255), Color(31, 31, 31, 255), 45);
	else
		m_pRenderer->GardientRect2(x, y, m_iWidth, m_iHeight, Color(53, 53, 53, 255), Color(31, 31, 31, 255), 45);

	int TextX = x + (m_iWidth / 2) - (10 / 2);
	int TextY = y + (m_iHeight / 2) - (10 / 2);
	if (untrusted)
		m_pRenderer->DrawText(TextX, TextY, 0, Selected, strText.c_str());
	else
		m_pRenderer->DrawText(TextX, TextY, 0, FontW, strText.c_str());

}



void CMenu::Draw(int x, int y, int w, int h, const char *Text)
{ 
	m_pRenderer->DrawRect(x, y, w, h, Color(28, 28, 28));
	m_pRenderer->DrawText(x, y, 0, Color(75, 75, 75, 255), Text);
}

bool tab[6] = { false,false,false,false,false,false };
void CMenu::RenderTab(int x, int y, float w, float h, std::string strText, int iIndex, int& iStatus)
{
	auto bActive = tab[iIndex];
	auto bHover = m_pMouse->IsInBox(x, y, w, h);

	if (bHover && m_pMouse->bMouse1released)
	{
		iStatus = iIndex;
		tab[iIndex] = !tab[iIndex];
	}

	if (bActive)
	{
		//g_pRenderSurface->Rect(x, y, w, h, Color2);
		m_pRenderer->GardientRect2(x, y, w, h, Selected, Color(Selected.R(), Selected.G(), Selected.B(), 255), 45);
		//g_pRenderSurface->GardientRect(x, y + h, w, 5, Color1, ValveSDK::Color(Color1.r() - 15, Color1.g() - 15, Color1.b() - 15, 255), 45);
	}
	else
		m_pRenderer->GardientRect2(x, y, w, h, MenuBG2, Color(MenuBG2.R(), MenuBG2.G(), MenuBG2.B(), 255), 45);


	//int iFontSize[2] = { 0 };
	//m_pRenderer->GetTextSize("FONT_MENU", strText.c_str(), iFontSize);


	m_pRenderer->DrawText(x + (w / 2) - (13 / 2), y + (h / 2) - (13 / 2), 0, FontW, strText.c_str());
}

int Keysss;
bool active;

void CMenu::RenderAimbotTab(int x, int y, int w, int h)
{
	//g_pRenderSurface->BorderBoxOutlinedText(x - 10, y - 10, 290, 250, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Aimbot");
	//g_pRenderSurface->BorderBoxOutlinedText(x + 290, y - 10, 290, 250, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Accuracy");
	//g_pRenderSurface->BorderBoxOutlinedText(x - 10, y + 250, 290, 185, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Target");
	//g_pRenderSurface->BorderBoxOutlinedText(x + 290, y + 250, 290, 185, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Movement");
	m_pRenderer->RectOutlined(x - 10, y - 40, w, h, 1, MenuBG, Color(0, 0, 0, 255));
	m_pRenderer->GardientRect2(x - 10, y - 40, w, 25, MenuTop, Color(MenuTop.R() - 5, MenuTop.G() - 5, MenuTop.B() - 5, 255), 45);
	m_pRenderer->DrawText(x + 2.5, y - 32.5, 0, FontW, "Aimbot");
	//m_pRenderer->RectOutlined2(x - 5, y - 10, 180, h - 35, 1, MenuTop);
	//m_pRenderer->RectOutlined2(x + 180, y - 10, w - 195, 140, 1, MenuTop);
	//m_pRenderer->RectOutlined2(x + 180, y + 135, w - 195, h - 180, 1, MenuTop);
	//Drag(w, 20);


		Slider(x, y + 55, 1,m_pConfig->m_AimbotFOV, 0, 180, "   FOV", "");
		Slider(x, y + 80, 1, m_pConfig->m_AimbotSmoothX, 0, 50, "Linear X", "");
		Slider(x, y + 100, 1, m_pConfig->m_AimbotSmoothY, 0, 50, "Linear Y", "");
		Slider(x + 300, y + 220, 1, m_pConfig->m_AimbotRcsX, 0, 50, "RCS Amount X", "");
		Slider(x + 300, y + 200, 1, m_pConfig->m_AimbotRcsY, 0, 50, "RCS Amount Y", "");
		Slider(x + 300, y + 80, 1, m_pConfig->m_AimbotStepX, 0, 50, "Step X", "");
		Slider(x + 300, y + 100, 1, m_pConfig->m_AimbotStepY, 0, 50, "Step Y", "");
		Slider(x + 300, y + 180, 1, m_pConfig->m_AimbotRCSDelay, 0, 100, "RCS Delay", "");
		DrawComboBox(x + 300, y + 60, "Smooth", m_pConfig->m_AimbotSmooth, 0, 3, SmoothList, "");

		DrawCheckBox(x + 300, y + 160, "RCS", m_pConfig->m_AimbotRCS, "");
		DrawCheckBox(x, y + 220, "AutoWall", m_pConfig->m_AimbotAutoWall, "");
		DrawCheckBox(x, y + 160, "Silent", m_pConfig->m_AimbotSilent, "");
		DrawCheckBox(x, y + 190, "pSilent", m_pConfig->m_AimbotPSilent, "");

		DrawCheckBox(x + 150, y + 160, "Type", m_pConfig->m_AimbotType, "");
		//DrawCheckBox(x + 150, y + 190, "AntiSmac", m_pConfig->m_AntiSmac, "");

		DrawCheckBox(x, y, "Enable", m_pConfig->m_AimbotActive, "");
		DrawComboBox(x + 300, y + 30, "Key",  m_pConfig->m_AimbotKeys , 1, 11, Keys, "");
		DrawComboBox(x, y + 30, "Spot", m_pConfig->m_AimbotHitbox, 2, 19, SpotList, "");
		DrawCheckBox(x + 300, y, "Auto Shoot", m_pConfig->m_AimbotAutoShoot, "");
}

void CMenu::RenderVisualsTab(int x, int y, int w, int h)
{
	//g_pRenderSurface->BorderBoxOutlinedText(x - 10, y - 10, 290, 250, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Aimbot");
	//g_pRenderSurface->BorderBoxOutlinedText(x + 290, y - 10, 290, 250, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Accuracy");
	//g_pRenderSurface->BorderBoxOutlinedText(x - 10, y + 250, 290, 185, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Target");
	//g_pRenderSurface->BorderBoxOutlinedText(x + 290, y + 250, 290, 185, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Movement");
	m_pRenderer->RectOutlined(x - 10, y - 40, w, h, 1, MenuBG, Color(0, 0, 0, 255));
	m_pRenderer->GardientRect2(x - 10, y - 40, w, 25, MenuTop, Color(MenuTop.R() - 5, MenuTop.G() - 5, MenuTop.B() - 5, 255), 45);
	m_pRenderer->DrawText(x + 2.5, y - 32.5, 0, FontW, "Visuals");
	m_pRenderer->RectOutlined2(x - 5, y - 10, 180, h - 35, 1, MenuTop);
	m_pRenderer->RectOutlined2(x + 180, y - 10, 305, h - 35, 1, MenuTop);
	//m_pRenderer->RectOutlined2(x + 180, y + 135, w - 195, h - 180, 1, MenuTop);
	//Drag(w, 20);

	DrawCheckBox(x, y, "Enable", m_pConfig->m_EspActive, "");
	DrawComboBox(x + 350, y, "Armor", m_pConfig->m_EspArmor, 1, 3, ESPArmor, "");
	DrawComboBox(x + 190, y, "Health", m_pConfig->m_EspHealth, 1, 3, ESPHealth, "");
	DrawComboBox(x + 190, y + 70, "Box", m_pConfig->m_EspBox, 3, 3, ESPStyle, "");
	//	DrawComboBox(x, y, "PITCH AA", m_pConfig->m_aapitch, 1, 5, pitchAA, "");
	DrawCheckBox(x, y + 20, "Skeleton", m_pConfig->m_EspBone, "");
	DrawCheckBox(x, y + 40, "Weapon", m_pConfig->m_EspWeapon, "");
	DrawCheckBox(x,y + 60, "Visible", m_pConfig->m_EspVisible, "");
	DrawCheckBox(x, y + 80, "Name", m_pConfig->m_EspName, "");
	DrawCheckBox(x, y + 100, "Hitbox", m_pConfig->m_EspHitbox, "");
	DrawCheckBox(x, y + 120, "Defuse", m_pConfig->m_EspDefuse, "");


}

void CMenu::RenderRender2Tab(int x, int y, int w, int h)
{
}
void CMenu::RenderMiscTab(int x, int y, int w, int h)
{
	//g_pRenderSurface->BorderBoxOutlinedText(x - 10, y - 10, 290, 250, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Aimbot");
	//g_pRenderSurface->BorderBoxOutlinedText(x + 290, y - 10, 290, 250, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Accuracy");
	//g_pRenderSurface->BorderBoxOutlinedText(x - 10, y + 250, 290, 185, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Target");
	//g_pRenderSurface->BorderBoxOutlinedText(x + 290, y + 250, 290, 185, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Movement");
	m_pRenderer->RectOutlined(x - 10, y - 40, w, h, 1, MenuBG, Color(0, 0, 0, 255));
	m_pRenderer->GardientRect2(x - 10, y - 40, w, 25, MenuTop, Color(MenuTop.R() - 5, MenuTop.G() - 5, MenuTop.B() - 5, 255), 45);
	m_pRenderer->DrawText(x + 2.5, y - 32.5, 0, FontW, "Misc");
	m_pRenderer->RectOutlined2(x - 5, y - 10, 180, h - 35, 1, MenuTop);
	m_pRenderer->RectOutlined2(x + 180, y - 10, w - 195, 140, 1, MenuTop);
	m_pRenderer->RectOutlined2(x + 180, y + 135, w - 195, h - 180, 1, MenuTop);

	Slider(x + 200, y + 90, 1, m_pConfig->m_MiscCrosshair, 0, 6, "Crosshair", "");
	DrawCheckBox(x + 200, y + 50, "Bunnyhop", m_pConfig->m_MiscBunnyHop, "");
	DrawCheckBox(x + 200, y + 70, "ShowRecoil Crosshair", m_pConfig->m_MiscShowRecoilCrosshair, "");
	//DrawCheckBox(x + 200, y + 30, "", m_pConfig->, "");

	//Drag(w, 20);


}

void CMenu::RenderConfigTab(int x, int y, int w, int h)
{
	//g_pRenderSurface->BorderBoxOutlinedText(x - 10, y - 10, 290, 250, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Aimbot");
	//g_pRenderSurface->BorderBoxOutlinedText(x + 290, y - 10, 290, 250, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Accuracy");
	//g_pRenderSurface->BorderBoxOutlinedText(x - 10, y + 250, 290, 185, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Target");
	//g_pRenderSurface->BorderBoxOutlinedText(x + 290, y + 250, 290, 185, 1, ValveSDK::Color(75, 75, 75), ValveSDK::Color(51, 51, 51), "Movement");
	m_pRenderer->RectOutlined(x - 10, y - 40, w, h, 1, MenuBG, Color(0, 0, 0, 255));
	m_pRenderer->GardientRect2(x - 10, y - 40, w, 25, MenuTop, Color(MenuTop.R() - 5, MenuTop.G() - 5, MenuTop.B() - 5, 255), 45);
	m_pRenderer->DrawText(x + 2.5, y - 32.5, 0, FontW, "Config");
	//m_pRenderer->RectOutlined2(x - 5, y - 10, 180, h - 35, 1, MenuTop);
	//m_pRenderer->RectOutlined2(x + 180, y - 10, w - 195, 140, 1, MenuTop);
	//m_pRenderer->RectOutlined2(x + 180, y + 135, w - 195, h - 180, 1, MenuTop);
	//Drag(w, 20);

	/*DrawComboBox(x, y, "Smooth", m_pConfig->Smoothtype, 2, 3, SmoothList, "");
	if (m_pConfig->Smoothtype == 1) // Step
	{
	Slider(x, y + 60, 1, m_pConfig->StepX, 0.0f, 100.0f, "Vertical", "");
	Slider(x, y + 90, 1, m_pConfig->StepY, 0.0f, 100.0f, "Horizontal", "");
	}
	else if (m_pConfig->Smoothtype == 2)
	{
	Slider(x, y + 60, 1, m_pConfig->SmoothX, 0.0f, 100.0f, "Vertical", "");
	Slider(x, y + 90, 1, m_pConfig->SmoothY, 0.0f, 100.0f, "Horizontal", "");
	}*/


	int iTextSize[2] = { 0 };
	auto bHoverReload = m_pMouse->IsInBox(x, y, 80, 20);
	m_pRenderer->DrawRectOut(x, y, 80, 20, bHoverReload ? Color(80, 80, 80, 220) : Color(40, 40, 40, 220), Color::Black());
	if (bHoverReload && m_pMouse->bMouse1released) {
		m_pConfig->Load();
	}

	m_pRenderer->DrawText(x + (80 / 2) - (iTextSize[0] / 2), y + (20 / 2) - (iTextSize[1] / 2), NULL, Color::White(), "Reload");

	auto bHoverSave = m_pMouse->IsInBox(x + 85, y, 80, 20);
	m_pRenderer->DrawRectOut(x + 85, y, 80, 20, bHoverSave ? Color(80, 80, 80, 220) : Color(40, 40, 40, 220), Color::Black());
	if (bHoverSave && m_pMouse->bMouse1released) {
		m_pConfig->Save();
	}

	m_pRenderer->DrawText(x + 85 + (80 / 2) - (iTextSize[0] / 2), y + (20 / 2) - (iTextSize[1] / 2), NULL, Color::White(), "Save");

}

void CMenu::RenderRemovalsTab(int x, int y, int w, int h)
{
	m_pRenderer->RectOutlined(x - 10, y - 40, w, h, 1, MenuBG, Color(0, 0, 0, 255));
	m_pRenderer->GardientRect2(x - 10, y - 40, w, 25, MenuTop, Color(MenuTop.R() - 5, MenuTop.G() - 5, MenuTop.B() - 5, 255), 45);
	m_pRenderer->DrawText(x + 2.5, y - 32.5, 0, FontW, "Removals");

	DrawCheckBox(x, y + 60, "No Visual Recoil", m_pConfig->m_RemVisualRecoil, "");
	DrawCheckBox(x, y + 90, "BackFlip Mode", m_pConfig->m_RemBackflip, "");
	DrawCheckBox(x, y + 120, "No Flash", m_pConfig->m_RemFlash, "");

	DrawCheckBox(x, y + 0, "No Spread", m_pConfig->m_RemSpread, "");
	DrawCheckBox(x, y + 30, "No Recoil", m_pConfig->m_RemRecoil, "");
}

static bool draggingR = false;
void CMenu::DragRagebot(int w, int h)
{
	static int iXDif = 0;
	static int iYDif = 0;
	bool bDrag = false;
	int iMousePosition[2] = { 0 };
	DrawMouse(m_pConfig->iMouseX, m_pConfig->iMouseY);

	int iCurrentPosition[2] = { Ragebot[0], Ragebot[1] };
	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h))
		draggingR = true;
	else if (!m_pMouse->bMouse1pressed)
		draggingR = false;

	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h) || draggingR)
	{
		if (!bDrag)
			bDrag = true;
		if (iXDif == -1 || iYDif == -1)
		{
			iXDif = m_pConfig->iMouseX - Ragebot[0];
			iYDif = m_pConfig->iMouseY - Ragebot[1];
		}
		Ragebot[0] += m_pConfig->iMouseX - (iXDif + iCurrentPosition[0]);
		Ragebot[1] += m_pConfig->iMouseY - (iYDif + iCurrentPosition[1]);
	}
	else
	{
		if (bDrag)
			bDrag = false;
		iXDif = -1;
		iYDif = -1;
	}
}

static bool draggingL = false;
void CMenu::DragLegitbot(int w, int h)
{
	static int iXDif = 0;
	static int iYDif = 0;
	bool bDrag = false;
	int iMousePosition[2] = { 0 };
	DrawMouse(m_pConfig->iMouseX, m_pConfig->iMouseY);

	int iCurrentPosition[2] = { Legitbot[0], Legitbot[1] };
	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h))
		draggingL = true;
	else if (!m_pMouse->bMouse1pressed)
		draggingL = false;

	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h) || draggingL)
	{
		if (!bDrag)
			bDrag = true;
		if (iXDif == -1 || iYDif == -1)
		{
			iXDif = m_pConfig->iMouseX - Legitbot[0];
			iYDif = m_pConfig->iMouseY - Legitbot[1];
		}
		Legitbot[0] += m_pConfig->iMouseX - (iXDif + iCurrentPosition[0]);
		Legitbot[1] += m_pConfig->iMouseY - (iYDif + iCurrentPosition[1]);
	}
	else
	{
		if (bDrag)
			bDrag = false;
		iXDif = -1;
		iYDif = -1;
	}
}
static bool draggingV = false;
void CMenu::DragVisuals(int w, int h)
{
	static int iXDif = 0;
	static int iYDif = 0;
	bool bDrag = false;
	int iMousePosition[2] = { 0 };
	DrawMouse(m_pConfig->iMouseX, m_pConfig->iMouseY);

	int iCurrentPosition[2] = { Visuals[0], Visuals[1] };
	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h))
		draggingV = true;
	else if (!m_pMouse->bMouse1pressed)
		draggingV = false;

	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h) || draggingV)
	{
		if (!bDrag)
			bDrag = true;
		if (iXDif == -1 || iYDif == -1)
		{
			iXDif = m_pConfig->iMouseX - Visuals[0];
			iYDif = m_pConfig->iMouseY - Visuals[1];
		}
		Visuals[0] += m_pConfig->iMouseX - (iXDif + iCurrentPosition[0]);
		Visuals[1] += m_pConfig->iMouseY - (iYDif + iCurrentPosition[1]);
	}
	else
	{
		if (bDrag)
			bDrag = false;
		iXDif = -1;
		iYDif = -1;
	}
}

static bool draggingRE = false;
void CMenu::DragRender2(int w, int h)
{
	static int iXDif = 0;
	static int iYDif = 0;
	bool bDrag = false;
	int iMousePosition[2] = { 0 };
	DrawMouse(m_pConfig->iMouseX, m_pConfig->iMouseY);

	int iCurrentPosition[2] = { Render2[0], Render2[1] };
	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h))
		draggingRE = true;
	else if (!m_pMouse->bMouse1pressed)
		draggingRE = false;

	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h) || draggingRE)
	{
		if (!bDrag)
			bDrag = true;
		if (iXDif == -1 || iYDif == -1)
		{
			iXDif = m_pConfig->iMouseX - Render2[0];
			iYDif = m_pConfig->iMouseY - Render2[1];
		}
		Render2[0] += m_pConfig->iMouseX - (iXDif + iCurrentPosition[0]);
		Render2[1] += m_pConfig->iMouseY - (iYDif + iCurrentPosition[1]);
	}
	else
	{
		if (bDrag)
			bDrag = false;
		iXDif = -1;
		iYDif = -1;
	}
}

static bool draggingM = false;
void CMenu::DragMisc(int w, int h)
{
	static int iXDif = 0;
	static int iYDif = 0;
	bool bDrag = false;
	int iMousePosition[2] = { 0 };
	DrawMouse(m_pConfig->iMouseX, m_pConfig->iMouseY);

	int iCurrentPosition[2] = { Misc[0], Misc[1] };
	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h))
		draggingM = true;
	else if (!m_pMouse->bMouse1pressed)
		draggingM = false;

	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h) || draggingM)
	{
		if (!bDrag)
			bDrag = true;
		if (iXDif == -1 || iYDif == -1)
		{
			iXDif = m_pConfig->iMouseX - Misc[0];
			iYDif = m_pConfig->iMouseY - Misc[1];
		}
		Misc[0] += m_pConfig->iMouseX - (iXDif + iCurrentPosition[0]);
		Misc[1] += m_pConfig->iMouseY - (iYDif + iCurrentPosition[1]);
	}
	else
	{
		if (bDrag)
			bDrag = false;
		iXDif = -1;
		iYDif = -1;
	}
}
static bool draggingC = false;
void CMenu::DragConfig(int w, int h)
{
	static int iXDif = 0;
	static int iYDif = 0;
	bool bDrag = false;
	int iMousePosition[2] = { 0 };
	DrawMouse(m_pConfig->iMouseX, m_pConfig->iMouseY);

	int iCurrentPosition[2] = { Configs[0], Configs[1] };
	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h))
		draggingC = true;
	else if (!m_pMouse->bMouse1pressed)
		draggingC = false;

	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h) || draggingC)
	{
		if (!bDrag)
			bDrag = true;
		if (iXDif == -1 || iYDif == -1)
		{
			iXDif = m_pConfig->iMouseX - Configs[0];
			iYDif = m_pConfig->iMouseY - Configs[1];
		}
		Configs[0] += m_pConfig->iMouseX - (iXDif + iCurrentPosition[0]);
		Configs[1] += m_pConfig->iMouseY - (iYDif + iCurrentPosition[1]);
	}
	else
	{
		if (bDrag)
			bDrag = false;
		iXDif = -1;
		iYDif = -1;
	}
}

static bool draggingRem = false;
void CMenu::DragRemovalsbot(int w, int h)
{
	static int iXDif = 0;
	static int iYDif = 0;
	bool bDrag = false;
	int iMousePosition[2] = { 0 };
	DrawMouse(m_pConfig->iMouseX, m_pConfig->iMouseY);

	int iCurrentPosition[2] = { Removals[0], Removals[1] };
	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h))
		draggingRem = true;
	else if (!m_pMouse->bMouse1pressed)
		draggingRem = false;

	if (m_pMouse->LeftClick(iCurrentPosition[0], iCurrentPosition[1], w, h) || draggingRem)
	{
		if (!bDrag)
			bDrag = true;
		if (iXDif == -1 || iYDif == -1)
		{
			iXDif = m_pConfig->iMouseX - Removals[0];
			iYDif = m_pConfig->iMouseY - Removals[1];
		}
		Removals[0] += m_pConfig->iMouseX - (iXDif + iCurrentPosition[0]);
		Removals[1] += m_pConfig->iMouseY - (iYDif + iCurrentPosition[1]);
	}
	else
	{
		if (bDrag)
			bDrag = false;
		iXDif = -1;
		iYDif = -1;
	}
}

/////////////////////////////////////////////////////

int m_iX, m_iY;
int m_iCurrentTap = 0;

void CMenu::DrawMainFrame(int x, int y)
{

	x = m_iX;
	y = m_iY;
	auto w = 500;
	auto h = 400;
	auto Renderw = 300;
	auto Renderh = 170;
	auto Aimbotw = 600;
	auto AimbotH = 300;
	auto Removalsw = 200;
	auto Removalsh = 300;
	auto mW = w;
	static float MenuTabSelection = -75.f;
	if (!m_pConfig->bShowGUI)
	{
		MenuTabSelection = -75.f;
	}
	if (!m_pConfig->bShowGUI)
		return;

	float iAddValue = ((fabs(MenuTabSelection) + 1.f) / 75.f) * 750.f;
	MenuTabSelection += (m_pServerData->frametime * iAddValue) * ((m_pConfig->bShowGUI) ? 1.f : -1.f);
	if (MenuTabSelection > 0)
		MenuTabSelection = 0.f;
	else if (MenuTabSelection <= -75.f)
		MenuTabSelection = -75.f;

	static std::string strTabs[5] = { "Aimbot", "Visuals", "Removals","Misc", "Configs" };
	int iScreenWidth, iScreenHeight;
	m_pEngine->GetScreenSize(iScreenWidth, iScreenHeight);
	int tabsize;
	if (iScreenWidth)
	{
		tabsize = iScreenWidth / 7;
	}
	for (int i = 0; i < 7; i++)
	{
		RenderTab(0 + (i) * (tabsize), MenuTabSelection, tabsize, 30, strTabs[i], i, m_iCurrentTap);
	}

	if (tab[0] == true)
	{
		RenderAimbotTab(Ragebot[0] + 10, Ragebot[1] + 40, Aimbotw, AimbotH);
		DragRagebot(Aimbotw, 20);
	}
	if (tab[1] == true)
	{
		RenderVisualsTab(Visuals[0] + 10, Visuals[1] + 40, w, h);
		DragVisuals(w, 20);
	}
	if (tab[2] == true)
	{
		RenderRemovalsTab(Removals[0] + 10, Removals[1] + 40, Removalsw, Removalsh);
		DragRemovalsbot(Removalsw, 20);
	}
	if (tab[3] == true)
	{
		RenderMiscTab(Misc[0] + 10, Misc[1] + 40, w, h);
		DragMisc(w, 20);
	}
	if (tab[4] == true)
	{
		RenderConfigTab(Configs[0] + 10, Configs[1] + 40, w, h);
		DragConfig(w, 20);
	}
}

void CMenu::DrawMenu()
{
	if (bLock)
	{
		bClick = false;
	}
	else
	{
		bClick = true;
	}

	if (GetAsyncKeyState(VK_INSERT) & 1)
	{
		m_pConfig->bShowGUI = !m_pConfig->bShowGUI;

		if (m_pConfig->bShowGUI)
			CloseAllComboBoxes();
	}

	if (m_pConfig->bShowGUI)
	{
		GetCursorPos(&Mouse);
		LPPOINT penis = &Mouse;
		ScreenToClient(GetForegroundWindow(), penis);

		Mouse.x = penis->x;
		Mouse.y = penis->y;
		m_pConfig->iMouseX = Mouse.x;
		m_pConfig->iMouseY = Mouse.y;

		m_pMouse->ClickHandler();
		DrawMouse(m_pConfig->iMouseX, m_pConfig->iMouseY);
		DrawMainFrame(m_pConfig->iMenuX, m_pConfig->iMenuY);
	}
}
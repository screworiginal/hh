#include "Main.h"
#include "Config.h"

void Startup( HMODULE hModule )
{
	//
	// Install hooks
	//
	Main::Startup( );

	//
	// Load config
	//
	Main::m_pConfig->SetModule( hModule );
	Main::m_pConfig->Load( );

	//
	// Wait for key input
	//
	while( !GetAsyncKeyState( VK_F11 ) )
		std::this_thread::sleep_for( std::chrono::milliseconds( 100 ) );

	//
	// Release hooks & custom class instances
	//
	Main::Release( );

	//
	// Wait till hooked functions execute
	//
	std::this_thread::sleep_for( std::chrono::seconds( 1 ) );

	//
	// Unload module
	//
	FreeLibraryAndExitThread( hModule, NULL );
}

BOOL WINAPI DllMain( HMODULE hModule, DWORD dwReason, LPVOID lpReserved )
{
	if( dwReason == DLL_PROCESS_ATTACH )
	{
		//
		// Disable thread library calls as we don't use them (DLL_THREAD_ATTACH/DETACH)
		//
		DisableThreadLibraryCalls( hModule );

		//
		// Start main thread
		//
		CreateThread( NULL, NULL, ( LPTHREAD_START_ROUTINE )Startup, hModule, NULL, NULL );
	}
	else if( dwReason == DLL_PROCESS_DETACH )
	{
		//
		// Release hooks & custom class instances
		//
		Main::Release( );
	}

	//
	// Succeeded
	//
	return TRUE;
}
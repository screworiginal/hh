#include "Color.h"

Color::Color( void )
	:	r( 0 ),
	g( 0 ),
	b( 0 ),
	a( 0 )
{

}

Color::Color( uint8_t r, uint8_t g, uint8_t b, uint8_t a )
	:	r( r ),
	g( g ),
	b( b ),
	a( a )
{

}

Color::Color( const Color& other )
{
	r = other.r;
	g = other.g;
	b = other.b;
	a = other.a;
}

Color& Color::operator=( const Color& other )
{
	r = other.r;
	g = other.g;
	b = other.b;
	a = other.a;

	return *this;
}

int Color::R( void ) const
{
	return r;
}

int Color::G( void ) const
{
	return g;
}

int Color::B( void ) const
{
	return b;
}

int Color::A( void ) const
{
	return a;
}

Color Color::None( void )
{
	return Color( 0, 0, 0, 0 );
}

Color Color::White( void )
{
	return Color( 255, 255, 255 );
}

Color Color::Black( void )
{
	return Color( 0, 0, 0 );
}

Color Color::Red( void )
{
	return Color( 255, 0, 0 );
}

Color Color::Green( void )
{
	return Color( 0, 255, 0 );
}

Color Color::Blue( void )
{
	return Color( 0, 0, 255 );
}

Color Color::Cyan( void )
{
	return Color( 0, 128, 255 );
}

Color Color::Yellow( void )
{
	return Color( 255, 255, 0 );
}
Color Color::Rainbow(void)
{
	static uint32_t cnt = 0;
	float freq = .001f;

	Color color = Color(
		std::sin(freq*cnt + 0) * 127 + 128,
		std::sin(freq*cnt + 2) * 127 + 128,
		std::sin(freq*cnt + 4) * 127 + 128,
		255);

	// Probably redundant
	if (cnt++ >= (uint32_t)-1) cnt = 0;

	return color;
}

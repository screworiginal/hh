#ifndef CONFIG_H
#define CONFIG_H

#pragma once

#include "Program.h"

class CConfig
{
public:
	void SetModule( HMODULE hModule );

	void Load( void );
	void Save( void );

private:
	HMODULE m_hModule;

public:
	bool m_AimbotActive;
	bool m_AimbotAutoShoot;
	bool m_AimbotType;
	float m_AimbotBone;
	int m_AimbotHitbox;
	float m_AimbotFOV;
	int m_AimbotKeys;
	int m_AimbotSmooth;
	bool m_AimbotRCS;
	float m_AimbotRCSDelay;
	bool m_AimbotSilent;
	bool m_AimbotPSilent;
	bool m_AimbotAutoWall;
	float m_AimbotRcsX;
	float m_AimbotRcsY;
	float m_AimbotSmoothX;
	float m_AimbotSmoothY;
	float m_AimbotStepX;
	float m_AimbotStepY;

	bool m_TriggerbotActive;
	bool m_TriggerbotPerfect;
    int m_TriggerbotKey;
	int m_TriggerbotHitbox;


	bool m_EspActive;
	int m_EspBox;
	int m_EspHealth;
	int m_EspArmor;
	bool m_EspBone;
	bool m_EspName;
	bool m_EspHitbox;
	bool m_EspWeapon;
	bool m_EspVisible;
	bool m_EspDefuse;

	bool m_RemSpread;
	bool m_RemRecoil;
	bool m_RemVisualRecoil;
	bool m_RemSmoke;
	bool m_RemFlash;
	bool m_RemBackflip;
	
	bool m_MiscAutoStrafe;
	bool m_MiscBunnyHop;
	float  m_MiscCrosshair;
	bool m_MiscShowRecoilCrosshair;

	float m_aayaw;
	float m_aapitch;
	int m_chokedpackets;


	bool m_SaveConfig;
	bool m_LoadConfig;


		int iMenuX = 0, iMenuY = 0;
		int iMouseX, iMouseY;
		bool bShowGUI, bPanicKey, bSigFail, bPlayerList = 0, bRadar2D = 0, bRadarBG = 0, bRadarName = 0, bEnemyOnlyRadar = 0;
		int iMonitorPosX = 20, iMonitorPosY = 300, iSavedRadarX, iSavedRadarY;
		int Menu_X = 450, Menu_Y = 300;
		float flRadarPos_x = 75, flRadarPos_y = 100;
};

#endif // CONFIG_H
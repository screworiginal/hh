#include "Entity.h"
#include "Main.h"
#include "Manager.h"

const Vector3& C_BaseEntity::GetMins( void )
{
	auto col = GetCollideable( );

	typedef const Vector3& ( __thiscall* GetMinsFn )( void* );
	return GetMethod<GetMinsFn>( col, 1 )( col );
}

const Vector3& C_BaseEntity::GetMaxs( void )
{
	auto col = GetCollideable( );

	typedef const Vector3& ( __thiscall* GetMaxsFn )( void* );
	return GetMethod<GetMaxsFn>( col, 2 )( col );
}

CList* C_BaseEntity::GetList( void )
{
	auto net = ( void* )( this + 0x8 );

	typedef CList* ( __thiscall* GetListFn )( void* );
	return GetMethod<GetListFn>( net, 2 )( net );
}

bool C_BaseEntity::IsDormant( void )
{
	auto net = ( void* )( this + 0x8 );

	typedef bool ( __thiscall* IsDormantFn )( void* );
	return GetMethod<IsDormantFn>( net, 8 )( net );
}

int C_BaseEntity::GetIndex( void )
{
	auto net = ( void* )( this + 0x8 );

	typedef int ( __thiscall* GetIndexFn )( void* );
	return GetMethod<GetIndexFn>( net, 9 )( net );
}

const model_t* C_BaseEntity::GetModel( void )
{
	auto ren = ( void* )( this + 0x4 );

	typedef const model_t* ( __thiscall* GetModelFn )( void* );
	return GetMethod<GetModelFn>( ren, 8 )( ren );
}

bool C_BaseEntity::SetupBones( Matrix3x4* pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime )
{
	auto ren = ( void* )( this + 0x4 );

	typedef bool ( __thiscall* SetupBonesFn )( void*, Matrix3x4*, int, int, float );
	return GetMethod<SetupBonesFn>( ren, 15 )( ren, pBoneToWorldOut, nMaxBones, boneMask, currentTime );
}

void* C_BaseEntity::GetCollideable( void )
{
	typedef void* ( __thiscall* GetCollideableFn )( void* );
	return GetMethod<GetCollideableFn>( this, 3 )( this );
}

const Vector3& C_BaseEntity::GetAbsOrigin( void )
{
	typedef const Vector3& ( __thiscall* GetAbsOriginFn )( void* );
	return GetMethod<GetAbsOriginFn>( this, 9 )( this );
}

const Vector3& C_BaseEntity::GetAbsAngles( void )
{
	typedef const Vector3& ( __thiscall* GetAbsAnglesFn )( void* );
	return GetMethod<GetAbsAnglesFn>( this, 10 )( this );
}

bool C_BaseEntity::IsPlayer( void )
{
	typedef bool ( __thiscall* IsPlayerFn )( void* );
	return GetMethod<IsPlayerFn>( this, 118 )( this );
}

int C_BaseEntity::GetTeamNumber( void )
{
	static auto var = Main::m_pManager->Get( "DT_BaseEntity", "m_iTeamNum" );

	return *( int* )( this + var );
}
bool C_BaseEntity::IsDefusing()
{
	static auto var = Main::m_pManager->Get("DT_CSPlayer", "m_bIsDefusing");

	return *(bool*)(this + var);
}
unsigned char C_BaseEntity::m_MoveType()
{
	return *(unsigned char*)(this + 0x134); // search for CCSGameMovement::CheckParameters
}

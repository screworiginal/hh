#ifndef MANAGER_H
#define MANAGER_H

#pragma once

#include "SDK.h"

class CManager
{
public:
							CManager( void );
							~CManager( void );

	int						Get( const std::string& szTable, const std::string& szName );

private:
	int						GetProp( const std::string& szTable, const std::string& szName );
	int						GetProp( RecvTable* pTable, const std::string& szName );

	RecvTable*				GetTable( const std::string& szName );

private:
	std::vector<RecvTable*>	m_pTableList;
};

#endif // MANAGER_H